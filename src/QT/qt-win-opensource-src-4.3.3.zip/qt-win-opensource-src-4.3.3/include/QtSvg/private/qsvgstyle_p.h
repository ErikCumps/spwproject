#include "../../../src/svg/qsvgstyle_p.h"
