#include "../../../tools/designer/src/lib/shared/qdesigner_widgetbox_p.h"
