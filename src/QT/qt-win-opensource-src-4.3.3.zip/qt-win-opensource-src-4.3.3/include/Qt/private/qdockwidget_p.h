#include "../../../src/gui/widgets/qdockwidget_p.h"
