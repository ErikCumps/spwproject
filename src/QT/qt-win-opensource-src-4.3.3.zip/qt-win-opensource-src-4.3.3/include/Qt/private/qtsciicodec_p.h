#include "../../../src/corelib/codecs/qtsciicodec_p.h"
