#include "../../../src/gui/widgets/qmdiarea_p.h"
