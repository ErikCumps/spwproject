#include "../../../tools/designer/src/lib/shared/qdesigner_propertyeditor_p.h"
