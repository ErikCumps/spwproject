#include "../../../tools/designer/src/lib/shared/promotiontaskmenu_p.h"
