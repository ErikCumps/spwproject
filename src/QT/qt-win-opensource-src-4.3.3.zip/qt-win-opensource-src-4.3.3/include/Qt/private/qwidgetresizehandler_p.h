#include "../../../src/gui/widgets/qwidgetresizehandler_p.h"
