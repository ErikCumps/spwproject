#include "../../../tools/designer/src/lib/shared/connectionedit_p.h"
