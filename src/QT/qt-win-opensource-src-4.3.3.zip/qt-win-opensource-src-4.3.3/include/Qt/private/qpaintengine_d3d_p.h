#include "../../../src/gui/painting/qpaintengine_d3d_p.h"
