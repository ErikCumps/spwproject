#include "../../../tools/designer/src/lib/shared/qscripthighlighter_p.h"
