#include "../../../src/gui/widgets/qwidgetanimator_p.h"
