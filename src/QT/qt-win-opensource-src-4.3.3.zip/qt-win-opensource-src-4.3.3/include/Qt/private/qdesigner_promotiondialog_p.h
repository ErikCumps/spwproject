#include "../../../tools/designer/src/lib/shared/qdesigner_promotiondialog_p.h"
