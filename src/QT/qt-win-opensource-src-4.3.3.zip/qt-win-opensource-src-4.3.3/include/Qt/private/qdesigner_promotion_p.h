#include "../../../tools/designer/src/lib/shared/qdesigner_promotion_p.h"
