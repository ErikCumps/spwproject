#include "../../../src/corelib/codecs/qsimplecodec_p.h"
