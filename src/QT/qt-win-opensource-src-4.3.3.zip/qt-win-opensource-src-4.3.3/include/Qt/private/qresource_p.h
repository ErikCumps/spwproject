#include "../../../src/corelib/io/qresource_p.h"
