#include "../../../src/corelib/kernel/qtranslator_p.h"
