#include "../../../src/qt3support/sql/q3sqlmanager_p.h"
