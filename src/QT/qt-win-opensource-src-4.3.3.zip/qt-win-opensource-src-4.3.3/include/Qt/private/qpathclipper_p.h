#include "../../../src/gui/painting/qpathclipper_p.h"
