#include "../../../src/gui/dialogs/qfileinfogatherer_p.h"
