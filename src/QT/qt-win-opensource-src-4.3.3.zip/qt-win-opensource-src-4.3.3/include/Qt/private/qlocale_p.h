#include "../../../src/corelib/tools/qlocale_p.h"
