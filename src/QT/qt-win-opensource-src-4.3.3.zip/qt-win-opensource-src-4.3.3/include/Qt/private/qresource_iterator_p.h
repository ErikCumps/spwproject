#include "../../../src/corelib/io/qresource_iterator_p.h"
