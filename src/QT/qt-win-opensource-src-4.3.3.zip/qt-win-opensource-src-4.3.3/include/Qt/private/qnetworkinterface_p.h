#include "../../../src/network/qnetworkinterface_p.h"
