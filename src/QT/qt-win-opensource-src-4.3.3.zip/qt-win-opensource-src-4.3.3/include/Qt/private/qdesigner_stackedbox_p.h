#include "../../../tools/designer/src/lib/shared/qdesigner_stackedbox_p.h"
