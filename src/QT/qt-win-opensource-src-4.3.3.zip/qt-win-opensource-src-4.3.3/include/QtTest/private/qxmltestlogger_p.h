#include "../../../tools/qtestlib/src/qxmltestlogger_p.h"
