#include "../../../src/script/qscriptecmaglobal_p.h"
