#include "../../../src/script/qscriptglobals_p.h"
