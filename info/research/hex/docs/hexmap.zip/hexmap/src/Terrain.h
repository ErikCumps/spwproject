#ifndef __TERRAIN_H
#define __TERRAIN_H

//-----------------------------------------------------------------------------
// Copyright (C) 2005 Steve Corbett
// www.scorbett.ca
// steve@scorbett.ca
//
// You may redistribute this code provided this copyright notice is left intact
//
//------------------------------------------------------------------------------
// Created on 2005-12-12 by scorbett
//     - Initial code.
//-----------------------------------------------------------------------------


// A special terrain movement value which means that no movement
// is permitted on this type of terrain:
#define NO_MOVEMENT 255


/**
 * A class to load terrain metadata and image data and provide access to it.
 * The most obvious component of terrain is the image data (i.e. terrain 
 * tiles).  However, there is other metadata associated with terrain as
 * well.  For example, each terrain tile has a "movement value" associated
 * with it, which is the penalty or bonus given to units trying to move
 * over the terrain in question.  
 * 
 * Terrain data is loaded from a terrain meta file.  The meta file currently
 * contains the following:
 *  
 *  - pixel dimensions of each terrain tile
 *  - pixel margin between terrain tiles (typically zero)
 *  - file name of image file containing actual terrain tiles
 *  - count of how many terrain tiles are present
 *  - movement values (1 per terrain tile)
 *
 * TODO is there any other metadata we need to store here? 
 */
class Terrain
{
  private:
  
    // The actual terrain tiles are stored in one big image.  The
    // terrain tiles can be laid out in one long row, or they can
    // be broken up into many rows to make it easier on the artist.
    // The only caveat is that the image has to be divided into
    // logical cells of hexSizeX*hexSizeY pixels each.  So, if you
    // 100 terrain tiles of 10x10 pixels each, you could make an
    // image of 1000x10 pixels, with 1 row of 100 tiles, or you
    // could make an image of 100x100 pixels, with 10 rows of 10
    // tiles.  Whatever.  The code will auto-detect what you've done
    // and will adjust accordingly.  
    SDL_Surface* terrainSurface;    

    // Pixel dimensions of each terrain tile:
    Uint8 hexSizeX;
    Uint8 hexSizeY;
    
    // Pixel margin between each tile.  Typically this will be
    // zero.  The only reason it's here at all is because the
    // map class can operate with or without terrain information,
    // and if you aren't using terrain information, you can space
    // your hexagons out a bit using this property.
    Uint8 hexMargin;
    
    // The number of terrain tiles we know about.
    Uint8 terrainTileCount;
    
    // A one dimensional array of "movement values".  
    Uint8* movementValues;
      
    // Normally this will be NULL.  If a load error occurs, this will
    // be set to a descriptive error message.
    char* errorMessage;
    
  public:
  
    // Creates a Terrain instance using the metadata contained in the
    // given file.  If the load fails for some reason, IsLoaded() will
    // return false and GetLoadError() will return a descriptive
    // error message.
    Terrain(char* terrainMetaFile);
    
    // Cleans up and destroys this instance.
    ~Terrain();
    
    // Returns true if all is well.  If this returns false, you can call
    // GetLoadError to get a descriptive error message.
    bool IsLoaded();
    
    // Returns NULL if all is well, or an error message if the constructor
    // failed to load the specified terrain metadata file.
    char* GetLoadError();

    // Returns the number of terrain tiles available.
    Uint8 GetTerrainTileCount();
    
    // Returns the movement value for the given terrain tile. 
    Uint8 GetMovementValue(Uint8 terrainIndex);
        
    // Draws the specified terrain tile into the specified surface at the
    // specified pixel co-ordinates.  If the terrain index given is invalid,
    // this method does nothing.
    void DrawTerrainTile(SDL_Surface* destSurface, 
                         int pixelX, int pixelY, 
                         Uint8 terrainIndex);
                         
    // Returns the pixel width of a single terrain tile.                         
    Uint8 GetHexSizeX();
    
    // Returns the pixel height of a single terrain tile.
    Uint8 GetHexSizeY();
    
    // Returns the pixel margin between terrain tiles (typically zero).
    Uint8 GetHexMargin();
};

#endif

