//-----------------------------------------------------------------------------
// Copyright (C) 2005 Steve Corbett
// www.scorbett.ca
// steve@scorbett.ca
//
// You may redistribute this code provided this copyright notice is left intact
//
//------------------------------------------------------------------------------
// This is a simple test driver for my HexMap class.
// Most of the interesting code is in HexMap.h/HexMap.cpp, so you
// might want to look there instead if you are curious as to how
// it all works.
//
//------------------------------------------------------------------------------
// Created on 2005-12-09 by scorbett
//     - Initial code.
// Updated on 2005-12-10 by scorbett
//     - Made the window resizable and set it up so that the map window
//       is dynamically resized as the window is resized.
//     - Added mouse motion event handling to highlight the current hexagon
//       as the mouse is moved over the map view.
// Updated on 2005-12-11 by scorbett
//     - Added scroll buttons in the bottom left to provide an alternative
//       to using the keyboard arrow keys for scrolling.
//     - Added a "show grid" button in the bottom right to provide a way
//       to toggle the display of hexagon borders.
//     - Added a "terrain" button in the bottom right to provide a way
//       to toggle the display of terrain tiles.
//     - Added an "exit" button in the bottom right since the ESC key may
//       not be intuitive enough for some people.
//     - Added some informational text in the bottom center of the window.
// Updated on 2005-12-12 by scorbett
//     - We now accept a .map file on the command line and parse our map
//       information out of there rather than hard code it as we used to.
//       This allows the user to specify their own .map files without having
//       to recompile the code.
// Released on 2005-12-13 by scorbett
//     - "milestone 1" - basic demonstration of grid visualization.
//     - Details at http://www.kuro5hin.org/story/2005/12/13/12341/770
// Updated on 2005-12-15 by scorbett
//     - Added support for passing Click() messages to the map as necessary.
//     - Added basic support for loading and displaying units.
//     - The cursor tracking and highlighting has been moved from here
//       into the map class, where it rightfully belongs.  Previously, we would
//       have to track mouse movements and tell the map to highlight the
//       current hex as necessary.  Now we just pass mouse motion events 
//       to the map class and let it interpret them.  
// Updated on 2005-12-20 by scorbett
//     - It seems that when running on windows, any attempt to resize the
//       window results in a segfault.  No idea why.  For now I have added
//       an #ifdef around the relevant code so that we simply disallow 
//       resizing when running on windows.
// Released on 2005-12-21 by scorbett
//     - "milestone 2" - demonstration of pathfinding and unit movement.
//     - Details at http://www.kuro5hin.org/story/2005/12/21/114942/60
// Updated on 2005-12-24 by scorbett
//     - Now using the frame rate functions in SDL_gfx to keep the game
//       animations running at a predictable FPS (previously would run
//       as fast as the host computer was capable of).
// Updated on 2005-12-26 by scorbett
//     - Added a couple of enemy units and now setting teams for each 
//       unit so we can test out the new combat capabilities.
//     - Now passing mouse right clicks to the map.
//     - Added support for scrolling the map vertically with the mouse wheel.
// Updated on 2005-12-27 by scorbett
//     - Now loading and supplying the map with a simple explosion animation
//       for when units get blowed up real good.
//     - Removed the arrow scroll buttons since they are taking up too
//       much space - also made the window non-resizable since at 800x600 we
//       don't need to scroll anyway.
//     - Expanded the instruction text.
//     - Added a "movement radius" toggle so you can see the movement costs
//       of each hexagon in your movement radius.
//     - Changed the configuration buttons from static images to dynamic
//       "CommandButton" instances to make them easier to change.
// Released on 2005-12-27 by scorbett
//     - "milestone 3" - demonstration of animation and (basic) combat.
//     - Details at TODO - update with URL when diary is posted
//-----------------------------------------------------------------------------


#include <stdio.h>
#include <stdlib.h>

#include "SDL.h"
#include "SDL_image.h"
#include "SDL_gfxPrimitives.h"
#include "SDL_framerate.h"
#include "Terrain.h"
#include "Unit.h"
#include "HexMap.h"


// Global; to be filled in within the main method
SDL_Surface* screen = NULL;


// Scrolling using the arrow keys or buttons will go by this many pixels:
#define NORMAL_SCROLL 2

// Scrolling with the mouse wheel will go by this many pixels:
#define WHEEL_SCROLL 12


// Quick and dirty struct to represent a command button
struct CommandButton
{
  SDL_Rect rect;
  char* text;
};


// Support function: draws a command button:
void DrawCommandButton(CommandButton* button, bool active)
{
  // Fill the background:
  int colour;
  if (active)
    colour = SDL_MapRGB(screen->format,53,170,118);
  else
    colour = SDL_MapRGB(screen->format,32,103,71);
  SDL_FillRect(screen,&(button->rect),colour);
  
  // Draw the border:
  int borderColour = 0xCC;
  if (! active)
    borderColour = 0xBB;
  rectangleRGBA(screen,button->rect.x,button->rect.y,
                button->rect.x+button->rect.w,
                button->rect.y+button->rect.h,
                borderColour,borderColour,borderColour,0xFF);
  
  int textX = button->rect.w/2 + button->rect.x;
  textX -= strlen(button->text) * 4;
  int textY = button->rect.y + 10;
  stringRGBA(screen,textX,textY,button->text,0xFF,0xFF,0xFF,0xFF);
}

// Support function: returns true if the mouse is in the given rect
bool IsMouseInRect(SDL_Rect* rect)
{
  int mouseX,mouseY;
  SDL_GetMouseState(&mouseX,&mouseY);
  return (mouseX >= rect->x && mouseX <= (rect->x+rect->w) &&
          mouseY >= rect->y && mouseY <= (rect->y+rect->h));
}


// Support function: write some informational text to the bottom
// center of the window:
void ShowInstructions(SDL_Surface* screen)
{
  int left = 40;
  int top = screen->h-140;
  stringRGBA(screen,left,top,"INSTRUCTIONS:",0xFF,0xFF,0xFF,0xFF);
  stringRGBA(screen,left,top+20,"- Click on a unit to select it and show its movement radius.",0xAA,0xAA,0xAA,0xFF);
  stringRGBA(screen,left,top+32,"- Click a highlighted hexagon to move the selected unit there.",0xAA,0xAA,0xAA,0xFF);
  stringRGBA(screen,left,top+44,"- Click a red (targetted) hexagon to destroy the enemy target.",0xAA,0xAA,0xAA,0xFF);  
  stringRGBA(screen,left,top+56,"- Notice that your movements are slowed by enemy ZOC (zone of control)",0xAA,0xAA,0xAA,0xFF);
  stringRGBA(screen,left,top+68,"- Notice that the \"tank\" is blocked by mountains, but not the plane.",0xAA,0xAA,0xAA,0xFF);
  stringRGBA(screen,left,top+80,"- Try to ignore the crappy artwork",0xAA,0xAA,0xAA,0xFF);
  stringRGBA(screen,left,top+92,"- Hit ESC or click Exit when done",0xAA,0xAA,0xAA,0xFF);
  stringRGBA(screen,left+155,top+115,"2005-12-20  www.scorbett.ca",0x4A,0xEA,0x7A,0xFF);
}


//////////////////////////////////////////////////////////////////////
// Entry point:
int main(int argc, char *argv[])
{
  // For the purpose of this test, we only need to initialize the 
  // video subsystem.
  if ( SDL_Init(SDL_INIT_VIDEO) < 0 )
  {
    printf("Unable to init SDL: %s\n", SDL_GetError());
    exit(1);
  }
  
  // Ensure SDL gets cleaned up regardless of how we exit.
  atexit(SDL_Quit);

  // Initialize a 800x600 resizable double-buffered screen:
  int SDLflags = SDL_HWSURFACE|SDL_DOUBLEBUF;
  screen=SDL_SetVideoMode(800,600,32,SDLflags);
  if (screen == NULL)
  {
    printf("Unable to set 640x480 video: %s\n", SDL_GetError());
    exit(1);
  }
  
  // Set a window caption (default seems to be nothing at all?)
  SDL_WM_SetCaption("HexMap Test Program","HexMap Test Program");

  // Margins around map display window:
  const int MAP_XMARGIN = 40;
  const int MAP_YMARGIN = 40;
  
  // We have to keep the display at a minimum size to prevent layout
  // problems with our scroll and command buttons:
  const int MIN_WINDOW_WIDTH = 800;
  const int MIN_WINDOW_HEIGHT = 250;  
  
  // Set up a display area for the map and draw a border around it:    
  SDL_Rect displayArea;
  displayArea.x = MAP_XMARGIN;
  displayArea.y = MAP_YMARGIN;
  displayArea.w = screen->w - MAP_XMARGIN*2;
  displayArea.h = screen->h - MAP_YMARGIN*5;
  rectangleColor(screen,displayArea.x-1,displayArea.y-1,
                 displayArea.x+displayArea.w+1,
                 displayArea.y+displayArea.h+1,
                 0xFFFF00FF);
    
  // Set up the map itself.  We have two options here - we can create
  // a terrained map or a non-terrained map.   If we create a non-terrained
  // map, we have control here in the code over stuff like the hexagon
  // pixel dimensions and margins and stuff.  If we create a terrained
  // map, all that information is specified in the map and terrain meta
  // files.  
  //
  // Here's an example of a non-terrained map with custom hexagon dimensions
  // of 54x32 and a hex margin of 4 pixels:  
  //int GRID_WIDTH = 20;
  //int GRID_HEIGHT = 20;
  //HexMap hexMap(screen,&displayArea,GRID_WIDTH,GRID_HEIGHT,54,32,4); 
  //
  // For this test program, however, we're going to load a .map file
  // that we expect to find in the current directory:
  HexMap hexMap(screen,&displayArea,"sample.map");
  
  // Ensure the load succeeded:
  if (! hexMap.IsLoaded())
  {
    printf(hexMap.GetLoadError());
    printf("\n");
    exit(1);
  }
  
  // Give the map a background colour so you can still see something
  // even if terrain and grid are toggled off:
  hexMap.SetMapBackgroundColour(0x22,0x22,0x22);
  
  // Load a sample of each type of unit:
  Unit flyingUnit("sample-flying.unit");
  Unit groundUnit("sample-ground.unit");
  
  // Ensure our units loaded:
  if (! flyingUnit.IsLoaded() || ! groundUnit.IsLoaded())
  {
    if (! flyingUnit.IsLoaded())
      printf("Flying unit: %s\n",flyingUnit.GetLoadError());
    else
      printf("Ground unit: %s\n",groundUnit.GetLoadError());
    exit(1);
  }
  
  // Load a few enemy targets to shoot at:
  Unit enemyUnit1("sample-enemy.unit");
  Unit enemyUnit2("sample-enemy.unit");
  Unit enemyUnit3("sample-enemy.unit");
  Unit enemyUnit4("sample-enemy.unit");
  Unit enemyUnit5("sample-enemy.unit");
  Unit enemyUnit6("sample-enemy.unit");
  
  // Ensure they loaded okay:
  if (! enemyUnit1.IsLoaded()) // only need to check the first guy
  {
    printf("Enemy unit: %s\n",enemyUnit1.GetLoadError());
    exit(1);
  }
  
  // Load a simple explosion animation:
  SDL_Surface* explosionAnim = IMG_Load("sample-explosion.png");
  if (! explosionAnim)
  {
    printf("Problem loading sample-explosion.png\n");
    exit(1);
  }
  hexMap.SetExplosionAnim(explosionAnim,54);
  
  // Set teams:
  flyingUnit.SetTeamID(BLUE_TEAM);
  groundUnit.SetTeamID(BLUE_TEAM);
  enemyUnit1.SetTeamID(GREEN_TEAM);
  enemyUnit2.SetTeamID(GREEN_TEAM);
  enemyUnit3.SetTeamID(GREEN_TEAM);
  enemyUnit4.SetTeamID(GREEN_TEAM);
  enemyUnit5.SetTeamID(GREEN_TEAM);
  enemyUnit6.SetTeamID(GREEN_TEAM);
  
  // Add the units to the map:
  hexMap.AddUnit(&flyingUnit,2,4);
  hexMap.AddUnit(&groundUnit,2,8);
  hexMap.AddUnit(&enemyUnit1,4,1);
  hexMap.AddUnit(&enemyUnit2,11,3);
  hexMap.AddUnit(&enemyUnit3,4,6);
  hexMap.AddUnit(&enemyUnit4,12,9);
  hexMap.AddUnit(&enemyUnit5,5,7);
  hexMap.AddUnit(&enemyUnit6,6,9);
  
  // Set up some command buttons:
  int buttonLeft = screen->w - 175;
  int buttonWidth = 155;
  CommandButton btnShowMovementCost;
  btnShowMovementCost.rect.x = buttonLeft;
  btnShowMovementCost.rect.y = screen->h - 140;
  btnShowMovementCost.rect.w = buttonWidth;
  btnShowMovementCost.rect.h = 24;
  btnShowMovementCost.text = "Show movement cost";
  CommandButton btnShowGrid;
  btnShowGrid.rect.x = buttonLeft;
  btnShowGrid.rect.y = screen->h - 107;
  btnShowGrid.rect.w = buttonWidth;
  btnShowGrid.rect.h = 24;
  btnShowGrid.text = "Show grid";
  CommandButton btnShowTerrain;
  btnShowTerrain.rect.x = buttonLeft;
  btnShowTerrain.rect.y = screen->h - 74;
  btnShowTerrain.rect.w = buttonWidth;
  btnShowTerrain.rect.h = 24;
  btnShowTerrain.text = "Show terrain";
  CommandButton btnExit;
  btnExit.rect.x = buttonLeft;
  btnExit.rect.y = screen->h - 41;
  btnExit.rect.w = buttonWidth;
  btnExit.rect.h = 24;
  btnExit.text = "Exit";  
  
  // Set up some loop flags and crap:
  int done=0;
  int deltaX = 0;
  int deltaY = 0;
  HexState defaultHexState = NO_BORDER;
  bool showTerrain = true;
  bool wheelScrolling = false;
  bool showMovementCost = false;

  // Frame rate manage allows us to keep the game running
  // at a predictable FPS:
  FPSmanager framerateManager;
  SDL_initFramerate(&framerateManager);
  SDL_setFramerate(&framerateManager,35);
  
  // Main game loop.  
  while(done == 0)
  {
    // SDL event polling:
    SDL_Event event;
    while (SDL_PollEvent(&event))
    {
      if (event.type == SDL_QUIT)  
        done = 1; 

      if (event.type == SDL_KEYDOWN)
      {
        // ESC key will exit the app:
        if (event.key.keysym.sym == SDLK_ESCAPE) 
          done = 1;
        
        // Keep an eye out for the arrow keys to allow scrolling:
        switch (event.key.keysym.sym)
        {
          case SDLK_LEFT: deltaX = -NORMAL_SCROLL; break;
          case SDLK_RIGHT: deltaX = NORMAL_SCROLL; break;
          case SDLK_UP: deltaY = -NORMAL_SCROLL; break;
          case SDLK_DOWN: deltaY = NORMAL_SCROLL; break;
        }
      }
      
      // Keep an eye out for mouse clicks on our command or arrow buttons:
      if (event.type == SDL_MOUSEBUTTONDOWN)
      {
        if (event.button.button == SDL_BUTTON_LEFT)
        {
          // Command buttons:
          if (IsMouseInRect(&(btnShowMovementCost.rect)))
          {
            showMovementCost = ! showMovementCost;
            hexMap.SetMovementCostVisible(showMovementCost);
          }
          if (IsMouseInRect(&(btnShowGrid.rect)))
          {
            defaultHexState = (defaultHexState==NO_BORDER) ? NORMAL:NO_BORDER;
            hexMap.SetDefaultHexState(defaultHexState);
          }
          else if (IsMouseInRect(&(btnShowTerrain.rect)))
            showTerrain = ! showTerrain;
          else if (IsMouseInRect(&(btnExit.rect)))
            done = 1;

          // Click in map window?
          else if (IsMouseInRect(&displayArea))
          {
            int mouseX,mouseY;
            SDL_GetMouseState(&mouseX,&mouseY);
            hexMap.LeftClick(mouseX,mouseY);
          }
        }
        
        // Also allow right clicks in the map window only:
        else if (event.button.button == SDL_BUTTON_RIGHT)
        {
          if (IsMouseInRect(&displayArea))
          {
            int mouseX,mouseY;
            SDL_GetMouseState(&mouseX,&mouseY);
            hexMap.RightClick(mouseX,mouseY);
          }
        }        
        
        // Finally, allow scrolling via the mouse wheel:
        else if (event.button.button == SDL_BUTTON_WHEELUP)
        {
          deltaY = -WHEEL_SCROLL;
          wheelScrolling = true;
        }
        else if (event.button.button == SDL_BUTTON_WHEELDOWN)
        {
          deltaY = WHEEL_SCROLL;
          wheelScrolling = true;
        }
      }
      
      // If the user was scrolling via the arrow buttons, 
      // make it stop when they let go of the mouse:
      if (event.type == SDL_MOUSEBUTTONUP)
      {
        deltaX = 0;
        
        // Unfortunately, we get the MOUSEBUTTONUP message immediately
        // after the MOUSEBUTTONDOWN message for wheel scrolls, so
        // we can't immediately set deltaY back to zero (otherwise the
        // wheel scroll won't work at all).  So, only reset deltaY
        // if we aren't wheel scrolling.  Resetting deltaY is
        // done later in the game loop for wheel scrolls.
        if (! wheelScrolling)
          deltaY = 0;
      }
      
      // If the user was scrolling via the keyboard arrow keys,
      // make it stop when they get off the key:
      if (event.type == SDL_KEYUP)
      {
        switch (event.key.keysym.sym)
        {
          case SDLK_LEFT: 
          case SDLK_RIGHT: deltaX = 0; break;
          case SDLK_UP: 
          case SDLK_DOWN: deltaY = 0; break;
        }
      }
      
      // Make a "cursor" follow the mouse if it is moved around the map window:
      if (event.type == SDL_MOUSEMOTION)
      {
        // We could bounds check the mouse x and y here, but it is redundant
        // as the map will do its own bounds checking.  So, hand ALL mouse 
        // motion events to the map and let the map decide what to respond to.
        hexMap.Cursor(event.motion.x,event.motion.y);
      }
    }

    // Scroll the map if required:
    if (deltaX != 0 || deltaY != 0)
      hexMap.ScrollBy(deltaX,deltaY);    

    // Show or hide the terrain tiles as requested:
    hexMap.SetTerrainVisible(showTerrain);
            
    // Render the map:
    hexMap.DrawMap();
    
    // Show configuration buttons:
    DrawCommandButton(&btnShowMovementCost,showMovementCost);
    DrawCommandButton(&btnShowGrid,(defaultHexState == NORMAL));
    DrawCommandButton(&btnShowTerrain,showTerrain);
    DrawCommandButton(&btnExit,done);

    // Draw informational text:
    ShowInstructions(screen);

    // Display the whole thing.
    SDL_Flip(screen);
    
    // If we were scrolling with the mouse wheel, cancel it now:
    if (wheelScrolling)
    {
      wheelScrolling = false;
      deltaY = 0;
    }
      
    // Keep it at a predictable FPS:
    SDL_framerateDelay(&framerateManager);
  }
  
  // Pause a bit (shows the Exit button depressed)
  SDL_Delay(250);

  // Clean up and we're done.
  SDL_FreeSurface(explosionAnim);
  
  return 0;
}


