#ifndef __TEAM_H
#define __TEAM_H

//-----------------------------------------------------------------------------
// Copyright (C) 2005 Steve Corbett
// www.scorbett.ca
// steve@scorbett.ca
//
// You may redistribute this code provided this copyright notice is left intact
//
//------------------------------------------------------------------------------
// Created on 2005-12-24 by scorbett
//     - Initial code.
//-----------------------------------------------------------------------------


// Each unit, factory, and base in the game must belong to a
// team (unless they are NEUTRAL).  For now, we're only going
// to define two teams, but when we go to add multiplayer
// support later this may change.
//
// The values may be OR'd together for ZOC calculations
// (i.e. if a hexagon is "owned" by more than one team).
#define NEUTRAL_TEAM 1
#define BLUE_TEAM 2
#define GREEN_TEAM 4


#endif

