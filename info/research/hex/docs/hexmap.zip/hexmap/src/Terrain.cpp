//-----------------------------------------------------------------------------
// Copyright (C) 2005 Steve Corbett
// www.scorbett.ca
// steve@scorbett.ca
//
// You may redistribute this code provided this copyright notice is left intact
//
//------------------------------------------------------------------------------
// Created on 2005-12-12 by scorbett
//     - Initial code.
//-----------------------------------------------------------------------------

#include <stdio.h>
#include <string.h>
#include <SDL.h>
#include <SDL_image.h>
#include "Terrain.h"


// Creates a Terrain instance using the metadata contained in the
// given file.  If the load fails for some reason, IsLoaded() will
// return false and GetLoadError() will return a descriptive
// error message.
Terrain::Terrain(char* terrainMetaFile)
{
  // Set defaults:
  terrainSurface = NULL;
  errorMessage = NULL;
  movementValues = NULL;
  terrainTileCount = 0;
  hexSizeX = 0;
  hexSizeY = 0;
  hexMargin = 0;
  
  // Attempt to parse terrain file:
  FILE* inFile = fopen(terrainMetaFile,"rb");
  
  // Ensure it is a version we can handle:
  Uint8 Version;
  fread(&Version,sizeof(Uint8),1,inFile);
  if (Version != 1)
  {
    fclose(inFile);
    errorMessage = new char[100];
    strcpy(errorMessage,"Unrecognized terrain file version.");
    return;
  }
  
  // Get hex dimensions and margin:
  fread(&hexSizeX,sizeof(Uint8),1,inFile);
  fread(&hexSizeY,sizeof(Uint8),1,inFile);
  fread(&hexMargin,sizeof(Uint8),1,inFile);
  
  // Get the total count of terrain tiles here:
  fread(&terrainTileCount,sizeof(Uint8),1,inFile);

  // Get the name of the terrain surface file:
  Uint8 stringLength;
  fread(&stringLength,sizeof(Uint8),1,inFile);
  if (stringLength == 0)
  {
    fclose(inFile);
    errorMessage = new char[100];
    strcpy(errorMessage,"Terrain file does not specify any terrain image(s).");
    return;
  }
  char* terrainImageFile = new char[stringLength+1];
  fread(terrainImageFile,sizeof(char),stringLength,inFile);
  terrainImageFile[stringLength] = '\0';

  // Try to load the terrain image:  
  terrainSurface = IMG_Load(terrainImageFile);
  if (! terrainSurface)
  {
    fclose(inFile);
    errorMessage = new char[100];
    strcpy(errorMessage,"Unable to load terrain image(s).");
    return;
  }
    
  // Now read all movement values for these tiles:
  movementValues = new Uint8[terrainTileCount];
  fread(movementValues,sizeof(Uint8),terrainTileCount,inFile);
  
  fclose(inFile);
}


// Cleans up and destroys this instance.
Terrain::~Terrain()
{
  if (movementValues)
    delete[] movementValues;
  if (terrainSurface)
    SDL_FreeSurface(terrainSurface);
  if (errorMessage)
    delete[] errorMessage;
}


// Returns true if all is well.  If this returns false, you can call
// GetLoadError to get a descriptive error message.
bool Terrain::IsLoaded()
{
  return errorMessage == NULL;
}


// Returns NULL if all is well, or an error message if the constructor
// failed to load the specified terrain metadata file.
char* Terrain::GetLoadError()
{
  return errorMessage;
}


// Returns the number of terrain tiles available.
Uint8 Terrain::GetTerrainTileCount()
{
  return terrainTileCount;
}
    

// Returns the movement value for the given terrain tile. 
Uint8 Terrain::GetMovementValue(Uint8 terrainIndex)
{
  if (! movementValues || terrainIndex >= terrainTileCount)
    return NO_MOVEMENT;
    
  return movementValues[terrainIndex];
}


// Draws the specified terrain tile into the specified surface at the
// specified pixel co-ordinates.  If the terrain index given is invalid,
// this method does nothing.
void Terrain::DrawTerrainTile(SDL_Surface* destSurface, 
                              int pixelX, int pixelY, 
                              Uint8 terrainIndex)
{
  // Do a sanity check on the index we were given:
  if (terrainIndex >= terrainTileCount)
    return;

  // Convert terrainIndex into 2D grid co-ordinates:
  int gridY = 0;
  int gridX = 0;
  int terrainTilesPerRow = terrainSurface->w/hexSizeX;
  while (terrainIndex > terrainTilesPerRow)
  {
    gridY++;
    terrainIndex -= terrainTilesPerRow;
  }
  gridX = terrainIndex;
  
  // Set up an SDL_Rect
  SDL_Rect sourceRect;
  sourceRect.w = hexSizeX;
  sourceRect.h = hexSizeY;
  sourceRect.x = gridX * hexSizeX;
  sourceRect.y = gridY * hexSizeY;
  
  // Set up a destination rect:
  SDL_Rect destRect;
  destRect.x = pixelX;
  destRect.y = pixelY;
  
  // Blit the image:
  SDL_BlitSurface(terrainSurface,&sourceRect,destSurface,&destRect);
}

                       
// Returns the pixel width of a single terrain tile.                         
Uint8 Terrain::GetHexSizeX()
{
  return hexSizeX;
}


// Returns the pixel height of a single terrain tile.
Uint8 Terrain::GetHexSizeY()
{
  return hexSizeY;
}


// Returns the pixel margin between terrain tiles (typically zero).
Uint8 Terrain::GetHexMargin()
{
  return hexMargin;
}


