#ifndef __HEXMAP_H
#define __HEXMAP_H

//-----------------------------------------------------------------------------
// Copyright (C) 2005 Steve Corbett
// www.scorbett.ca
// steve@scorbett.ca
//
// You may redistribute this code provided this copyright notice is left intact
//
//------------------------------------------------------------------------------
// Created on 2005-12-09 by scorbett
//     - Initial code.
// Updated on 2005-12-10 by scorbett
//     - Added ResizeDisplayArea(SDL_Rect*) so that the map display area
//       can be changed on the fly.
//     - Added IsHexVisible(int,int) so callers can determine whether or
//       not a hexagon at a given grid location is currently visible.
//       This is also used internally by DrawHex as an optimization so
//       that hexagons that don't need to be drawn aren't.
//     - Moved the computation of hexagon points to the constructor and
//       now store the results in a class variable.  This prevents a bit
//       of extra math from being done each time the map is drawn.
//     - Added SetHexStatusByPixel(int,int) which allows callers to change
//       the status of a hexagon not by its grid location but by its 
//       pixel location.  
//     - Added SetAllHexStatus(HexStatus) to provide a way to quickly
//       set all hexagons to the given status.
//     - Added code to ensure that the map is centered within the display
//       area in the case where the map is smaller than the display area.
//       (previous behaviour was to display the map in the upper left
//        of the display area, which looks odd).
//     - Added CenterOnHex(int,int) which allows callers to center the
//       map on a given hexagon (by its grid location).
//     - Added SetMapBackgroundColour(int) so callers don't have to put
//       up with a hard-coded background colour.
// Updated on 2005-12-11 by scorbett
//     - Added a constructor that takes some terrain information so we
//       can show terrain tiles.  However, at this point, even though it
//       works, the interface is extremely basic and needs a lot of work.
//       Specifically, I want the callers to just have to specify the
//       location of a .map file that we will parse and get our terrain
//       information from there.  This .map file should also contain
//       other map parameters such as the width and height of each hexagon,
//       and the margin, since those things will ultimately affect how we
//       draw terrain tiles.
//     - Added a toggle to show/hide terrain information (if available).
//     - Corrected an off-by-one bug in DrawHex that was causing us to
//       draw one pixel too far horizontally and vertically when drawing
//       our hexagon borders.  This also seems to have fixed the odd
//       HEX_MARGIN problem spotted earlier where a value of 1 would actually
//       leave a margin of 0.
// Updated on 2005-12-12 by scorbett
//     - Improved the clunky terrain interface created yesterday.  Now, callers
//       merely have to specify a .map file in the constructor, and the code
//       parses out all map and terrain information to create the map. 
//     - Added an IsLoaded() method that will return false if something
//       went wrong when loading the .map file.  If you create a non-terrained
//       map, this will always return true.
//     - Added a GetLoadError() that will return a string detailing what
//       went wrong if IsLoaded() returns false.
//     - Added MAX_GRID_SIZE_X/Y to keep grids to a sane size.
//     - Replaced "int" with "Uint8" in many places (grid size, hexagon
//       pixel dimensions/margin, etc).  I doubt the memory savings will be
//       significant, but it makes better sense this way even if there
//       is no performance bonus.
// Released on 2005-12-13 by scorbett
//     - "milestone 1" - basic demonstration of grid visualization.
//     - Details at http://www.kuro5hin.org/story/2005/12/13/12341/770
// Updated on 2005-12-13 by scorbett
//     - Corrected a geometry bug in the Initialize() method where we were 
//       pre-calculating the hexagon border points.  The previous approach
//       required careful selection of hexagon dimensions in order to 
//       yield results that looked good.  The new code uses a better approach
//       whose only catch is that the width of the hexagon has to be greater
//       than the height.  A width:height ratio of about 1.5:1 looks great.
//     - Disabled antialiasing of the hexagon borders - this was only needed
//       due to the previously crappy geometry code mentioned above.  Now 
//       that that has been squared away, we don't need to antialias the
//       hexagon borders (this should improve performance somewhat as well).
// Updated on 2005-12-15 by scorbett
//     - Began implementation of pathfinding - still in progress.
//     - Moved some of the mouse handling stuff into this class where it
//       rightfully belongs.  Specifically, added the Click() and Cursor()
//       methods, which are used to track and highlight a current cursor.
//       The Click() method can also be used to select units.
//     - Added some support methods and properties in regards to the above.
//     - Added preliminary support for units.  This is currently very
//       basic and is pretty much limited to displaying them and allowing
//       a Click() to select one.  We don't yet show movement radius or
//       allow movement or combat.
//     - Created PixelToGrid() and moved the co-ordinate conversion stuff
//       in there rather than duplicate it all over the place.
// Updated on 2005-12-16 by scorbett
//     - Completed pathfinding code - now takes terrain into consideration.
//     - Added SetDefaultHexStatus so callers can toggle the grid display
//       on or off (default off).
//     - Added GridToPixel() to match the PixelToGrid() added yesterday.
//     - Began implementation of movement radius calculations - this is
//       still in progress.
// Updated on 2005-12-20 by scorbett
//     - Completed the movement radius calculations started on 2005-12-16.
//     - Fixed a bug in GridToPixel that was not taking staggered columns
//       into account (must have gotten lost when I moved that code into
//       its own method on 2005-12-16, because is used to work just fine).
//     - Moved adjacency calculations into their own method
//       (AreHexagonsAdjacent) since it was being done both in pathfinding
//       and movement radius calculations.  Also added pretty ASCII-art
//       comments to try to explain what the method is doing in detail.
//     - Added some EXTREMELY basic animation capabilities during a 
//       unit movement.  Right now this just highlights the movement path
//       for a second or two and then just teleports the unit from the
//       start point to the end point.  This will obviously be improved
//       as part of the next milestone.
// Released on 2005-12-21 by scorbett
//     - "milestone 2" - demonstration of pathfinding and unit movement.
//     - Details at http://www.kuro5hin.org/story/2005/12/21/114942/60
// Updated on 2005-12-23 by scorbett
//     - Renamed "HexStatus" to "HexState" to be more consistent with
//       terminology used elsewhere.
//     - Introduced "MapState" to describe different states that the
//       map engine can be in.   
//     - Removed the basic animation capabilities added on 2005-12-20 and
//       replaced with proper animation handlers, namely:
//           - InitiateUnitMovement()
//           - UpdateUnitMovement()
//           - TerminateUnitMovement()
//       The above methods all assume that only one unit may move at a time.
//       Note - these methods do not yet compensate for staggered columns,
//       so a little bit of work remains there.
// Updated on 2005-12-24 by scorbett
//     - Completed the animation code started yesterday.  
// Updated on 2005-12-26 by scorbett
//     - Added GetZOC and GetUnitAt to help in movement/combat calculations.
//     - Renamed Click() to LeftClick() and added a RightClick() so that
//       we now get more information about mouse clicks.  We now make use
//       of the RightClick() to cancel unit selection.
//     - Added a "currentTeam" property so that the map engine knows which
//       player is currently giving commands.  This is pretty basic and
//       will probably be enhanced or replaced later.
//     - Modified LeftClick() so that you can only click to select units
//       that are on your team (clicking an enemy unit does nothing).
//     - Renamed FindRadius to FindMovementRadius to be more specific.
//     - Added FindTargetRadius to find and highlight all target enemy units.
//     - Modified SelectUnit so that when selecting a unit, you see all
//       targetted enemy units as well as the movement radius of that unit.
//     - Modified the unit movement code so that a target radius is 
//       re-calculated when the move is complete (so if you move up next
//       to an enemy unit, the enemy will be targetted automatically).
//     - Stubbed in some basic "combat" code to be fleshed out later (right
//       now just prints out a message indicating combat should take place
//       between two given units).
//     - Modified the pathfinding/movementRadius code to take enemy ZOC into
//       account so that you can't move through an enemy's zone of control.
//     - Added "showMovementCost" originally as a debug tool, but it looked
//       so nifty I decided to keep it as an option (will probably come in
//       handy when we get to advanced terrain later, but will almost 
//       certainly be removed before the final game is released).
// Updated on 2005-12-27 by scorbett
//     - Modified target radius calculations to take minimum and maximum
//       attack ranges into account (previously was just maximum).  This
//       will be used later for artillery calculations.
//     - Corrected a problem in GetZOC where we were unconditionally returning
//       a team id in the case where a unit of that team was sitting in
//       the given hexagon.  This was added as an optimization but it turns
//       out not to work - it buggers up pathfinding in the case where two
//       units of differing teams are sitting next to each other and a third
//       unit tries to move near them.  
//     - Modified the cursor handling code so that instead of merely drawing
//       a highlighted border around the cursor hex, we fill it with a semi-
//       transparent fill colour.  This is done via the new method FillHex.
//     - Also now showing targets with a red filled hexagon, instead of merely
//       a red border.
//     - Added SetExplosionAnim so that callers have a way of specifying
//       the graphic to use for explosions (when a unit is destroyed)
//     - Added EXPLOSION_TIMEOUT which is the number of milliseconds to
//       show each frame of an explosion.
//     - Added EXPLOSION_ANIM to MapState to define the state when
//       the map is drawing an explosion.
//     - Added StartExplosion() and UpdateExplosion() for animation purposes.
//     - Added DoCombat() as an extremely basic approach to handling
//       combat between units.  This will be enhanced as time goes by
//       to better handle defense/attack calculations.  Right now the
//       combat ends with the immediate destruction of the defending
//       unit (horribly basic, but good enough for now).
// Released on 2005-12-27 by scorbett
//     - "milestone 3" - demonstration of animation and (basic) combat.
//     - Details at TODO - update with URL when diary is posted
//-----------------------------------------------------------------------------

#include <vector>

// Grid cannot be more than this many hexagons wide/tall.
// (well, strictly speaking, they could be, but memory and
//  performance start to become issues after a certain point).
#define MAX_GRID_SIZE_X 200
#define MAX_GRID_SIZE_Y 200

// Default pixel width and height of hexagons.
// This can be overridden in the constructor if desired.
// This should be an even number for the hexagons to line
// up correctly.
#define DEFAULT_HEX_WIDTH 60
#define DEFAULT_HEX_HEIGHT 40

// Default pixel margin between hexagons.
// This can be overridden in the constructor if desired.
//   A value of 0 means no pixels between hexagons (default)
//   A value of 1 means 1 pixel between hexagons
//   Larger values will space the hexagons out further
#define DEFAULT_HEX_MARGIN 0

// Default state of each hexagon.  This can be
// overridden via SetDefaultHexState()
#define DEFAULT_HEX_STATUS NO_BORDER

// Default number of milliseconds before the cursor will
// be hidden if no cursor movement is detected.
// This can be overridden via SetCursorTimeout
#define DEFAULT_CURSOR_TIMEOUT 500

// Value used to indicate the cursor is not on the map:
#define INVALID_CURSOR 255

// Determines how many steps it takes for a unit to move from one
// hexagon to another hexagon.
//   Lower this value to make units move slower (but smoother).
//   Increase this valud to make units move faster (but choppier).
// This can be set via the SetUnitMovementRate() method.
// Don't set this to zero because we divide by it.
#define DEFAULT_UNIT_MOVEMENT_RATE 7

// Determines the number of milliseconds to show each frame
// of an explosion animation.  This cannot be overridden as yet.
#define EXPLOSION_TIMEOUT 250


// Describes what kind of border should be drawn around
// a hexagon.  The default value is NO_BORDER.
enum HexState
{
  NO_BORDER,
  NORMAL,
  HIGHLIGHTED,
  TARGETTED,
  CURSOR
};

// Describes the current state of the map engine.
// This is retrieved by GetMapState() and cannot
// be set directly by the caller.
enum MapState
{
  READY,
  UNIT_MOVING,
  EXPLOSION_ANIM,
  COMBAT,
  AI_THINKING,
  PAUSED
};


// This is used internally for targetting enemy units.
// Basically we build a list of hexagons that are 
// currently targetted, then the DrawHex() method
// can mark those hexagons appropriately.
//
// Do not delete instances of this struct!
// Use DeallocateTargetRadius() instead.
struct TargetRadius
{
  Unit* targettingUnit;
  Uint8 numTargets;
  Uint8* pointsX;
  Uint8* pointsY;
};


// Describes a path between two grid points.  
//
// This is only used internally.
//
// Do not delete instances of this struct!
// Use DeallocateGridPath() instead.
struct GridPath
{
  Uint8 startX;
  Uint8 startY;
  Uint8 endX;
  Uint8 endY;
  Uint8 numPoints;
  Uint8* pointsX;
  Uint8* pointsY;
};


// Describes a unit movement, including the
// path that the unit will take.  This is
// used internally for animation purposes and
// is not exposed to the caller.
//
// Do not delete instances of this struct!
// Use InitiateUnitMovement() to start moving a unit
// and TerminateUnitMovement() will be called 
// automatically when the move is complete.
struct UnitMovementInfo
{
  Unit* movingUnit;
  GridPath* gridPath;
  Uint32 startTick;
  Uint8 gridDestX;
  Uint8 gridDestY;
  Uint8 currentNode; // index into gridPath->pointsXY
  Uint8 currentStep; // from 0 to unitMovementRate-1
  Uint32 currentPixelX;
  Uint32 currentPixelY;
};


// Describes an explosion.  This is used internally
// for animation purposes and is not exposed to the caller.
//
// This is created by StartExplosion and will be 
// terminated automatically by UpdateExplosion.
struct ExplosionInfo
{
  Uint32 startTick;
  Uint8 currentFrame;
  Uint32 pixelX;
  Uint32 pixelY;
};


// Describes the movement radius of a given unit
// at a given position.  Depending on the type
// of unit, this may take terrain features into
// account.  For example, a tank sitting next to
// a mountain range will not include the mountain
// tiles in its movement radius.  
//
// This is only used internally.
//
// Do not delete instances of this struct!
// Use DeallocateMovementRadius() instead.
struct MovementRadius
{
  Unit* unit;
  Uint8 numPoints;
  Uint8* pointsX;
  Uint8* pointsY;
  Uint8* movementCost;
};


// This struct is used extensively in pathfinding.
//
// This is only used internally.
struct GridPathNode
{
  Uint8 gridX;
  Uint8 gridY;
  Uint8 distanceFromStart; // the "G" score in A*
  Uint8 distanceToEnd;     // the "H" score in A*
  GridPathNode* parentNode;
};


// This struct is used when calculating movement the
// movement radius of a unit.
//
// This is only used internally.
struct RadiusNode
{
  Uint8 gridX;
  Uint8 gridY;
  Uint8 costFromStart;
  RadiusNode* parentNode;
};


/** 
 * Provides facilities for displaying a scrollable hexagon-based map.
 * The map is very configurable - you can adjust the pixel size of 
 * hexagons, the margin between hexagons, the number of hexagons
 * horizontally and vertically, etc.  The constructor accepts many 
 * parameters to customize the grid.
 *
 * If the map is larger than the display area you specify in the
 * constructor, scrolling facilities are provided automatically.  
 */
class HexMap
{
  private:
  
    // If terrain tiles are not being used, this colour will be
    // used as a background for the map.  Even if terrain tiles
    // are used, however, this colour is still important because
    // it will be used to fill in any space between the map and
    // the edge of the display area (i.e. if the map is smaller
    // than the display area).
    // Default value for this property is black - use 
    // SetMapBackgroundColour to change.
    int mapBackgroundColour;
    
    // Same as above, but used when drawing directly to the
    // displayBuffer instead of our internal buffer.
    // This is set automatically and thus is not exposed
    // directly to the caller.
    int displayBackgroundColour;
    
    // Each time the map is drawn, all hexagons will be defaulted
    // to this state.  This is typically NO_BORDER, but if callers
    // want to see the hex grid, they can set it to something else.
    HexState defaultHexState;
    
    // Defines the current state of the map itself.  Typically this
    // will be READY, indicating that user input is accepted.  If
    // the current state is anything other than READY, user input
    // such as mouse motion and clicks will be ignored.
    MapState mapState;
    
    // Defines the previous state of the map.  This is useful for
    // certain things like UNIT_MOVING, which can be triggered either
    // from a READY state or a AI_THINKING state.  When the unit move
    // completes, we need to revert to whatever state we were in before.
    MapState previousMapState;
    
    // Flag indicating whether or not to show terrain tiles.
    // If the map was constructed without terrain information, then
    // this flag does nothing.  
    bool showTerrain;
    
    // Flag indicating whether or not to show movement costs.
    // This is for debug purposes and will not be surfaced in the
    // final game.  Looks neat though.
    bool showMovementCost;

    // Specifies a period of time to wait before hiding the cursor
    // if no cursor movement is detected.  Value is in milliseconds.
    // A value of zero means never hide the cursor.
    int cursorTimeout;
    
    // The current cursor location (may be CURSOR_INVALID if we
    // have not yet seen cursor activity):
    Uint8 cursorX;
    Uint8 cursorY;
    
    // Specifies the tick count when we last saw cursor activity.
    // A value of 0 means we have not yet seen cursor activity.
    // We use this to "time out" the cursor (i.e. hide it after a
    // certain period of inactivity).
    Uint32 lastCursorTick;

    // Determines how many steps it takes for a unit to move from one
    // hexagon to another.  See comment for DEFAULT_UNIT_MOVEMENT_RATE
    // for details.  
    Uint8 unitMovementRate;

    // There can be at most one unit moving at a time:
    UnitMovementInfo* unitMovementInfo;
    
    // There can be at most one explosion at a time:
    ExplosionInfo* explosionInfo;    
    
    // If the map is larger than the display area, these variables
    // are used to store the pixel offset of the current view window. 
    int scrollX; 
    int scrollY; 
  
    // Dimensions of the map (in hexagons)
    Uint8 gridSizeX; // # of hexagons wide
    Uint8 gridSizeY; // # of hexagons tall
    
    // Dimensions of the map (in pixels)
    // These are auto-calculated based on gridSizeX and gridSizeY.
    int mapPixelWidth; // # of pixels wide
    int mapPixelHeight; // # of pixels tall
    
    // Pixel dimensions of each hexagon.
    Uint8 hexSizeX; 
    Uint8 hexSizeY; 
    
    // Our hexagons overlap each other horizontally due to our
    // honeycomb pattern.  This means that the width of each column
    // of hexagons is NOT the same as the width of an individual hexagon.
    // This value is calculated in the Initialize() method.
    Uint8 hexCellWidth; 
    
    // Pixel margin between hexagons. 
    // See comment for DEFAULT_HEX_MARGIN for more info.
    Uint8 hexMargin; 

    // This string will be set to NULL normally.  If something goes
    // wrong when attempting to load a .map file, it will be set
    // to a descriptive error message that can be retrieved via
    // the GetLoadError() method.
    char* errorMessage;
    
    // Where to blit the rendered map.  This is typically the
    // screen, but can be any valid SDL_Surface.    
    // This is supplied by the caller in the constructor.
    SDL_Surface* displaySurface; 

    // An internal surface where we will render our map.  This is 
    // created and used internally, and never seen by the caller.
    SDL_Surface* bufferSurface; 

    // A handle on an explosion animation which we'll use when
    // units are destroyed.
    SDL_Surface* explosionSurface;

    // Number of pixels wide for the explosion animation.
    Uint8 explosionAnimWidth;
    
    // Number of frames present for the explosion animation (auto-calculated).
    Uint8 explosionFrames;
            
    // A handle on a Terrain class, which may be NULL if we have no
    // terrain information.  
    Terrain* terrain;
    
    // An array [gridSizeX*gridSizeY] of indeces into the terrainSurface.
    // This tells us which terrain tile to display for each hexagon.
    // This may be NULL if we have no terrain information.
    Uint8* terrainIndeces;
    
    // Co-ordinates supplied by the caller that tell us where 
    // exactly within "displaySurface" we should blit our map.
    // Note that this rect may be modified for internal use
    // (this is done in the case where the map is smaller than
    //  the display area - we adjust this rect so the map is
    //  centered nicely within the actual display area).
    SDL_Rect displayArea; 
    
    // The original co-ordinates of the display area as given
    // to us by the caller.  Unlike "displayArea", these
    // co-ordinates are never modified internally.  
    SDL_Rect originalDisplayArea;
    
    // An array [gridSizeX*gridSizeY] that tells us the border state
    // of each hexagon on the map. 
    HexState* hexState; 
    
    // We precompute the points for a hexagon and store them in these
    // class variables.  This is a bit of an optimization that prevents
    // a little bit of math from having to be done if a hex needs a border.
    Uint8* hexBorderPointsX; 
    Uint8* hexBorderPointsY; 

    // An internal list of Unit pointers.
    std::vector<Unit*> unitList;
    
    // There can be at most one selected unit:
    Unit* selectedUnit;    

    // This indicates which team is currently giving commands.  
    Uint8 currentTeam;
        
    // There can be at most one movement radius showing:
    MovementRadius* currentMovementRadius;

    // There can be at most one target radius showing:
    TargetRadius* currentTargetRadius;
    
    // Internal method to move the given unit from the given start location
    // to the given destination.  The movement will be animated by 
    // UpdateMovement() and terminates automatically once the unit
    // has reached its destination.  During the move, the map state is
    // set to UNIT_MOVING and no user input is allowed.
    void InitiateUnitMovement(Unit* unit, Uint8 gridDestX, Uint8 gridDestY);
    
    // Internal method to update unit movement if it is currently taking place:
    void UpdateUnitMovement();
    
    // Internal method invoked automatically by UpdateUnitMovement when a unit
    // has arrived at its destination.
    void TerminateUnitMovement();

    // Internal method invoked as necessary by DoCombat to signal the start
    // of an explosion animation.
    void StartExplosion(Uint8 gridX, Uint8 gridY);
    
    // Internal method to update any currently animated explosion.
    void UpdateExplosion();
    
    // Internal method to stop an explosion animation when finished.
    void TerminateExplosion();
    
    // Internal method to handle combat between the two given units.
    void DoCombat(Unit* attackingUnit, Unit* defendingUnit);
            
    // Internal method to draw the hexagon at the given grid co-ordinates.
    void DrawHex(Uint8 gridX, Uint8 gridY); 
    
    // Internal method to fill the hexagon (if necessary) at the given
    // grid co-ordinates.  Whether or not a fill is performed is dependent
    // upon the HexState of the given hexagon.
    void FillHex(Uint8 gridX, Uint8 gridY);
    
    // Internal method called by ScrollBy and ScrollTo.
    // If the map has scrolled too far in any direction, this method
    // will keep it in check.
    void CheckScrollPosition(); 

    // Internal method to parse out the specified map file.  Called only
    // from the constructor.
    bool ParseMapFile(char* mapFile);
        
    // Internal method to set up the class properties - this is only invoked
    // from the constructors and is only invoked once.  For documentation
    // of the parameters, see the constructors.
    void Initialize(SDL_Surface* dispSurface, SDL_Rect* dispArea,
                    Uint8 gridWidth, Uint8 gridHeight,
                    Uint8 hexagonWidth=DEFAULT_HEX_WIDTH, 
                    Uint8 hexagonHeight=DEFAULT_HEX_HEIGHT,
                    Uint8 hexagonMargin=DEFAULT_HEX_MARGIN);
                    
    // Internal method to convert the given pixel co-ordinates into 
    // grid co-ordinates.  Returns false if the given pixel location
    // is off the grid, true if the conversion succeeded.
    bool PixelToGrid(int pixelX, int pixelY, Uint8* gridX, Uint8* gridY);

    // Internal method to convert the given grid co-ordinates into
    // pixel co-ordinates.  Returns false if the given grid location
    // is off the grid, true if the conversion succeeded.
    bool GridToPixel(Uint8 gridX, Uint8 gridY, int* pixelX, int* pixelY);
                        
    // Internal method to estimate the distance (in grid units) between
    // the given grid points. This is a rough estimate that will typically be
    // a bit higher than the actual distance.
    Uint8 GetDistanceBetween(Uint8 x1, Uint8 y1, Uint8 x2, Uint8 y2);

    // Internal method to estimate the distance (in grid units) between
    // the given GridPathNode objects.  This is a rough estimate that will 
    // typically be a bit higher than the actual distance.
    Uint8 GetDistanceBetween(GridPathNode* startPoint, GridPathNode* endPoint);

    // Internal method to determine whether two hexagons are adjacent.
    // This is not as straightforward as you might expect because of
    // our staggered columns.  This method returns true if the two
    // hexagons are adjacent (i.e. share a side).
    bool AreHexagonsAdjacent(Uint8 gridX1, Uint8 gridY1, 
                             Uint8 gridX2, Uint8 gridY2);   
    
    // Internal method to highlight all the hexagons on the given GridPath.
    void ShowGridPath(GridPath* path);
    
    // Internal method to highlight all the hexagons in the
    // given MovementRadius:
    void ShowMovementRadius(MovementRadius* radius);
    
    // Internal debug method to show the cost associated with moving to
    // each hexagon in the given movement radius.
    void ShowMovementCost(MovementRadius* radius);
    
    // Internal method to highlight all the hexagons in the given TargetRadius:
    void ShowTargetRadius(TargetRadius* radius);
    
    // Internal function to find a GridPathNode in the given list and return it.
    // If no such node was found, NULL is returned.  Matches are determined
    // by comparing the gridX and gridY.  
    GridPathNode* FindGridPathNode(std::vector<GridPathNode*>* nodeList, 
                                   GridPathNode* nodeToFind);

    // Internal function to find a RadiusNode in the given list and return it.
    // If no such node was found, NULL is returned.  Matches are determined
    // by comparing the gridX and gridY.
    RadiusNode* FindRadiusNode(std::vector<RadiusNode*>* nodeList,
                               RadiusNode* nodeToFind);
                               
    // Internal method to report if a given hexagon is within the given
    // movement radius or not.
    bool FindRadiusNode(MovementRadius* radius, Uint8 gridX, Uint8 gridY);
    
    // Internal method to report if a given hexagon is within the given
    // target radius or not.
    bool FindTargetNode(TargetRadius* radius, Uint8 gridX, Uint8 gridY);                           
    
    // Internal method to release all memory associated with a GridPath:
    void DeallocateGridPath(GridPath* path);
    
    // Internal method to release all memory associated with a movement radius:
    void DeallocateMovementRadius(MovementRadius* radius);
    
    // Internal method to release all memory associated with a target radius:
    void DeallocateTargetRadius(TargetRadius* radius);                           
    
    // Internal method to find a path between two grid points and returns it.
    // Return value will be NULL if no such path exists (i.e. the way is 
    // blocked by terrain).  Caller must delete the GridPath struct after 
    // using it.  If "obeyTerrain" is true (default), terrain tiles will be 
    // taken into account to slow or block movement.  If it is false (i.e. 
    // for flying units, terrain is ignored).
    GridPath* FindPath(Unit* movingUnit, Uint8 x2, Uint8 y2);

    // Internal method that exists to support the FindPath method.  This 
    // method evaluates all the nodes in the given openList, picks the "best" 
    // one, then evaluates all of its neighbors.  Return value is NULL if the 
    // path has not yet been found, or the final step if the path is found.                       
    GridPathNode* FindPath_EvaluateNode(GridPathNode* startNode, 
                                        GridPathNode* endNode,
                                        int maximumRadius,
                                        Uint8 movingTeam,
                                        std::vector<GridPathNode*>* openList,
                                        std::vector<GridPathNode*>* closedList,
                                        bool obeyTerrain);
                                    
    // Internal method to find the movement radius of the given unit.  Terrain 
    // will be taken into account if the unit is a ground based unit (flying 
    // units are immune to terrain effects).  
    MovementRadius* FindMovementRadius(Unit* unit);
    
    // Internal method that exists to support the FindMovementRadius method.  
    // This method evaluates all the nodes in the given openList, and adds to 
    // the closedList all nodes that the unit can move to.  When the search is
    // complete, the method will return false and the closedList will contain 
    // all viable moves.
    bool FindMovementRadius_EvaluateNode(int maximumRadius,
                                 Unit* movingUnit,
                                 RadiusNode* startNode,
                                 std::vector<RadiusNode*>* openList,
                                 std::vector<RadiusNode*>* closedList,
                                 bool obeyTerrain);

    // Internal method to find the target radius of the given unit.  Most 
    // units can only target enemies that are directly adjacent to them.
    // However, some units (such as artillery), can target units that
    // are not adjacent.  The return value will be NULL if there are no
    // enemy units within attack range.
    TargetRadius* FindTargetRadius(Unit* unit);
    
    // Internal method that exists to support the FindTargetRadius method.
    // This method will evaluate every node in the given open list, and sort
    // them into the given nonTarget list and target list.  When the method 
    // returns false, it means that the maximum attack range has been 
    // exhausted.  At that point, the targetList will contain all viable 
    // targets.
    bool FindTargetRadius_EvaluateNode(Uint8 minAttackRange,
                                       Uint8 maxAttackRange,
                                       Uint8 attackingTeam,
                                       std::vector<RadiusNode*>* openList,
                                       std::vector<RadiusNode*>* nonTargetList,
                                       std::vector<RadiusNode*>* targetList);
                                           
  public:
  
    // Constructs a non-terrained map and prepares it for use.
    //   dispSurface - where should we blit the rendered map?
    //   dispArea - where in dispSurface should we blit the map?
    //   gridWidth - number of hexagons wide
    //   gridHeight - number of hexagons tall
    //   hexagonWidth (optional) - pixel width of each hexagon 
    //   hexagonHeight (optional) - pixel height of each hexagon
    //   hexagonMargin (optional) - pixel margin between hexagons
    //
    // NOTE - this constructor assumes you don't want to use
    //        any terrain tiles (the background of the map can be 
    //        influenced at any time via SetMapBackgroundColour).
    HexMap(SDL_Surface* dispSurface, SDL_Rect* dispArea, 
           Uint8 gridWidth, Uint8 gridHeight,
           Uint8 hexagonWidth=DEFAULT_HEX_WIDTH, 
           Uint8 hexagonHeight=DEFAULT_HEX_HEIGHT, 
           Uint8 hexagonMargin=DEFAULT_HEX_MARGIN);

    // Constructs a terrained map and prepares it for use.
    //   dispSurface - where should we blit the rendered map?
    //   dispArea - where in dispSurface should we blit the map?
    //   mapFile - name of a file containing map data.
    //
    // This constructor will attempt to read all relevant map properties
    // from "mapFile".  The IsLoaded() method will return true or
    // false to indicate how the load went.  If something went wrong,
    // the GetLoadError() method can be used to get a descriptive
    // error message.
    //
    // NOTE - terrain can be shown or hidden using the SetTerrainVisible()
    //        method (default is to show it).
    HexMap(SDL_Surface* dispSurface, SDL_Rect* dispArea, char* mapFile);
           
    // Destructor - performs any necessary cleanup.
    ~HexMap();

    // Returns true unless something went wrong when parsing the .map file
    // specified in the constructor.  Use GetLoadError() to get a descriptive
    // error message.  Note that if you created this HexMap instance using
    // the other constructor (to make a non-terrained map), this method
    // will always return true.
    bool IsLoaded();
    
    // Returns NULL if the map is properly loaded and ready to go.
    // If something went wrong while loading the .map file, this method
    // will return a descriptive string.
    char* GetLoadError();
    
    // Sets a colour that will be used to paint the background behind
    // the map.  (This is generally only useful if you aren't using
    // terrain tiles, or if the map is smaller than the display area).
    void SetMapBackgroundColour(Uint8 r, Uint8 g, Uint8 b);

    // Sets an image that will be used as an explosion animation.
    // Multiple frames can be provided by making the image
    // "imgWidth"*numFrames wide.
    void SetExplosionAnim(SDL_Surface* surface, Uint8 imgWidth);
    
    // Specifies whether or not you want to show movement costs when
    // displaying a movement radius.  This is for debugging purposes,
    // and will probably be removed for the final product. 
    // Looks neat though.
    void SetMovementCostVisible(bool visible);
    
    // Tells the map what the default hexagon state is. 
    // This is typically NO_BORDER, but you can change it to
    // NORMAL if you want to see the grid.
    void SetDefaultHexState(HexState state);
            
    // Tells the map whether or not to render the terrain tiles.  
    // If the map was constructed without terrain information, then
    // this method does nothing.
    void SetTerrainVisible(bool isVisible);
    
    // Returns true if the hexagon at the given grid co-ordinates is
    // currently visible (may be false if the map is scrolled somewhere
    // else at the moment).
    bool IsHexVisible(Uint8 gridX, Uint8 gridY); 
    
    // Returns the current border state of the hexagon
    // at the given grid co-ordinates:
    HexState GetHexState(Uint8 gridX, Uint8 gridY); 
    
    // Sets all hexagons to the given border state:
    void SetAllHexState(HexState state);
    
    // Sets the border state of the hexagon at the given
    // grid-co-ordinates:
    void SetHexState(Uint8 gridX, Uint8 gridY, HexState state); 
    
    // Sets the border state of the hexagon at the
    // given pixel co-ordinates:
    void SetHexStateByPixel(int pixelX, int pixelY, HexState state);

    // Returns the current state of the map.  If the current state is
    // anything other than READY, user input is ignored.
    MapState GetMapState();

    // Sets the rate of speed at which units move from hexagon to
    // hexagon during unit movement animations.  See the comment
    // for DEFAULT_UNIT_MOVEMENT_RATE for details.
    void SetUnitMovementRate(Uint8 rate);
            
    // Sets the number of milliseconds that must elapse with no 
    // cursor activity before the cursor is hidden.  Value is 
    // in milliseconds.  A value of 0 means never hide the cursor.
    void SetCursorTimeout(int newTimeout);
    
    // Scrolls the map by the given amount.
    // (values can be positive for scrolling right/down
    //  or negative for scrolling left/up).
    // Values are in pixels.
    // This method does nothing if the display area is larger than the map.
    void ScrollBy(int deltaX, int deltaY); 
    
    // Immediately changes the scroll position to the given pixel
    // co-ordinates.  
    // This method does nothing if the display area is larger than the map.
    void ScrollTo(int newX, int newY); 
    
    // Changes the map scroll position (if necessary) so that the
    // hexagon at the given grid co-ordinates is centered.
    // This method does nothing if the display area is larger than the map.
    void CenterOnHex(Uint8 gridX, Uint8 gridY); 
    
    // Dynamically changes the display area where the rendered map should
    // be blitted.  This can be called at any time (typically when your
    // window is resized, but whatever).  
    void ResizeDisplayArea(SDL_Rect* newDisplayArea); 

    // Adds the given unit at the given co-ordinates:
    void AddUnit(Unit* unit, Uint8 gridX, Uint8 gridY);
    
    // Selects the given unit.  If you specify NULL as the unit, 
    // this method will unselect any currently selected unit.
    void SelectUnit(Unit* unit);
    
    // Renders the map and displays it.
    void DrawMap(); 
    
    // Called to simulate a left mouse click at the given pixel location:
    void LeftClick(int pixelX, int pixelY);
    
    // Called to simulate a right mouse click at the given pixel location:
    void RightClick(int pixelX, int pixelY);
    
    // Called to simulate mouse/cursor movement at the given pixel location:
    void Cursor(int pixelX, int pixelY);
    
    // Returns the ZOC of a given hexagon.  In the case of hexagons that are
    // that are overlapped (i.e. adjacent to multiple units of differing
    // teams), the return value will be an OR'd combination of team codes.
    // If there are no units adjacent to the given hexagon, NEUTRAL_TEAM
    // is returned.
    Uint8 GetZOC(Uint8 gridX, Uint8 gridY);
    
    // Returns a pointer to the unit that occupies the given hexagon, or
    // NULL if there isn't a unit sitting there:
    Unit* GetUnitAt(Uint8 gridX, Uint8 gridY);
    
    // Sets the "current" team.  Only one team can give orders at a time.
    void SetCurrentTeam(Uint8 team);
};


#endif // __HEXMAP_H

