//-----------------------------------------------------------------------------
// Copyright (C) 2005 Steve Corbett
// www.scorbett.ca
// steve@scorbett.ca
//
// You may redistribute this code provided this copyright notice is left intact
//
//------------------------------------------------------------------------------
// Created on 2005-12-09 by scorbett
//     - Initial code.
// Updated on 2005-12-10 by scorbett
//     - Added ResizeDisplayArea(SDL_Rect*) so that the map display area
//       can be changed on the fly.
//     - Added IsHexVisible(int,int) so callers can determine whether or
//       not a hexagon at a given grid location is currently visible.
//       This is also used internally by DrawHex as an optimization so
//       that hexagons that don't need to be drawn aren't.
//     - Moved the computation of hexagon points to the constructor and
//       now store the results in a class variable.  This prevents a bit
//       of extra math from being done each time the map is drawn.
//     - Added SetHexStatusByPixel(int,int) which allows callers to change
//       the status of a hexagon not by its grid location but by its 
//       pixel location.  
//     - Added SetAllHexStatus(HexStatus) to provide a way to quickly
//       set all hexagons to the given status.
//     - Added code to ensure that the map is centered within the display
//       area in the case where the map is smaller than the display area.
//       (previous behaviour was to display the map in the upper left
//        of the display area, which looks odd).
//     - Added CenterOnHex(int,int) which allows callers to center the
//       map on a given hexagon (by its grid location).
//     - Added SetMapBackgroundColour(int) so callers don't have to put
//       up with a hard-coded background colour.
// Updated on 2005-12-11 by scorbett
//     - Added a constructor that takes some terrain information so we
//       can show terrain tiles.  However, at this point, even though it
//       works, the interface is extremely basic and needs a lot of work.
//       Specifically, I want the callers to just have to specify the
//       location of a .map file that we will parse and get our terrain
//       information from there.  This .map file should also contain
//       other map parameters such as the width and height of each hexagon,
//       and the margin, since those things will ultimately affect how we
//       draw terrain tiles.
//     - Added a toggle to show/hide terrain information (if available).
//     - Corrected an off-by-one bug in DrawHex that was causing us to
//       draw one pixel too far horizontally and vertically when drawing
//       our hexagon borders.  This also seems to have fixed the odd
//       HEX_MARGIN problem spotted earlier where a value of 1 would actually
//       leave a margin of 0.
// Updated on 2005-12-12 by scorbett
//     - Improved the clunky terrain interface created yesterday.  Now, callers
//       merely have to specify a .map file in the constructor, and the code
//       parses out all map and terrain information to create the map. 
//     - Added an IsLoaded() method that will return false if something
//       went wrong when loading the .map file.  If you create a non-terrained
//       map, this will always return true.
//     - Added a GetLoadError() that will return a string detailing what
//       went wrong if IsLoaded() returns false.
//     - Added MAX_GRID_SIZE_X/Y to keep grids to a sane size.
//     - Replaced "int" with "Uint8" in many places (grid size, hexagon
//       pixel dimensions/margin, etc).  I doubt the memory savings will be
//       significant, but it makes better sense this way even if there
//       is no performance bonus.
// Released on 2005-12-13 by scorbett
//     - "milestone 1" - basic demonstration of grid visualization.
//     - Details at http://www.kuro5hin.org/story/2005/12/13/12341/770
// Updated on 2005-12-13 by scorbett
//     - Corrected a geometry bug in the Initialize() method where we were 
//       pre-calculating the hexagon border points.  The previous approach
//       required careful selection of hexagon dimensions in order to 
//       yield results that looked good.  The new code uses a better approach
//       whose only catch is that the width of the hexagon has to be greater
//       than the height.  A width:height ratio of about 1.5:1 looks great.
//     - Disabled antialiasing of the hexagon borders - this was only needed
//       due to the previously crappy geometry code mentioned above.  Now 
//       that that has been squared away, we don't need to antialias the
//       hexagon borders (this should improve performance somewhat as well).
// Updated on 2005-12-15 by scorbett
//     - Began implementation of pathfinding - still in progress.
//     - Moved some of the mouse handling stuff into this class where it
//       rightfully belongs.  Specifically, added the Click() and Cursor()
//       methods, which are used to track and highlight a current cursor.
//       The Click() method can also be used to select units.
//     - Added some support methods and properties in regards to the above.
//     - Added preliminary support for units.  This is currently very
//       basic and is pretty much limited to displaying them and allowing
//       a Click() to select one.  We don't yet show movement radius or
//       allow movement or combat.
//     - Created PixelToGrid() and moved the co-ordinate conversion stuff
//       in there rather than duplicate it all over the place.
// Updated on 2005-12-16 by scorbett
//     - Completed pathfinding code - now takes terrain into consideration.
//     - Added SetDefaultHexStatus so callers can toggle the grid display
//       on or off (default off).
//     - Added GridToPixel() to match the PixelToGrid() added yesterday.
//     - Began implementation of movement radius calculations - this is
//       still in progress.
// Updated on 2005-12-20 by scorbett
//     - Completed the movement radius calculations started on 2005-12-16.
//     - Fixed a bug in GridToPixel that was not taking staggered columns
//       into account (must have gotten lost when I moved that code into
//       its own method on 2005-12-16, because is used to work just fine).
//     - Moved adjacency calculations into their own method
//       (AreHexagonsAdjacent) since it was being done both in pathfinding
//       and movement radius calculations.  Also added pretty ASCII-art
//       comments to try to explain what the method is doing in detail.
//     - Added some EXTREMELY basic animation capabilities during a 
//       unit movement.  Right now this just highlights the movement path
//       for a second or two and then just teleports the unit from the
//       start point to the end point.  This will obviously be improved
//       as part of the next milestone.
// Released on 2005-12-21 by scorbett
//     - "milestone 2" - demonstration of pathfinding and unit movement.
//     - Details at http://www.kuro5hin.org/story/2005/12/21/114942/60
// Updated on 2005-12-23 by scorbett
//     - Renamed "HexStatus" to "HexState" to be more consistent with
//       terminology used elsewhere.
//     - Introduced "MapState" to describe different states that the
//       map engine can be in.   
//     - Removed the basic animation capabilities added on 2005-12-20 and
//       replaced with proper animation handlers, namely:
//           - InitiateUnitMovement()
//           - UpdateUnitMovement()
//           - TerminateUnitMovement()
//       The above methods all assume that only one unit may move at a time.
//       Note - these methods do not yet compensate for staggered columns,
//       so a little bit of work remains there.
// Updated on 2005-12-24 by scorbett
//     - Completed the animation code started yesterday.  
// Updated on 2005-12-26 by scorbett
//     - Added GetZOC and GetUnitAt to help in movement/combat calculations.
//     - Renamed Click() to LeftClick() and added a RightClick() so that
//       we now get more information about mouse clicks.  We now make use
//       of the RightClick() to cancel unit selection.
//     - Added a "currentTeam" property so that the map engine knows which
//       player is currently giving commands.  This is pretty basic and
//       will probably be enhanced or replaced later.
//     - Modified LeftClick() so that you can only click to select units
//       that are on your team (clicking an enemy unit does nothing).
//     - Renamed FindRadius to FindMovementRadius to be more specific.
//     - Added FindTargetRadius to find and highlight all target enemy units.
//     - Modified SelectUnit so that when selecting a unit, you see all
//       targetted enemy units as well as the movement radius of that unit.
//     - Modified the unit movement code so that a target radius is 
//       re-calculated when the move is complete (so if you move up next
//       to an enemy unit, the enemy will be targetted automatically).
//     - Stubbed in some basic "combat" code to be fleshed out later (right
//       now just prints out a message indicating combat should take place
//       between two given units).
//     - Modified the pathfinding/movementRadius code to take enemy ZOC into
//       account so that you can't move through an enemy's zone of control.
//     - Added "showMovementCost" originally as a debug tool, but it looked
//       so nifty I decided to keep it as an option (will probably come in
//       handy when we get to advanced terrain later, but will almost 
//       certainly be removed before the final game is released).
// Updated on 2005-12-27 by scorbett
//     - Modified target radius calculations to take minimum and maximum
//       attack ranges into account (previously was just maximum).  This
//       will be used later for artillery calculations.
//     - Corrected a problem in GetZOC where we were unconditionally returning
//       a team id in the case where a unit of that team was sitting in
//       the given hexagon.  This was added as an optimization but it turns
//       out not to work - it buggers up pathfinding in the case where two
//       units of differing teams are sitting next to each other and a third
//       unit tries to move near them.  
//     - Modified the cursor handling code so that instead of merely drawing
//       a highlighted border around the cursor hex, we fill it with a semi-
//       transparent fill colour.  This is done via the new method FillHex.
//     - Also now showing targets with a red filled hexagon, instead of merely
//       a red border.
//     - Added SetExplosionAnim so that callers have a way of specifying
//       the graphic to use for explosions (when a unit is destroyed)
//     - Added EXPLOSION_TIMEOUT which is the number of milliseconds to
//       show each frame of an explosion.
//     - Added EXPLOSION_ANIM to MapState to define the state when
//       the map is drawing an explosion.
//     - Added StartExplosion() and UpdateExplosion() for animation purposes.
//     - Added DoCombat() as an extremely basic approach to handling
//       combat between units.  This will be enhanced as time goes by
//       to better handle defense/attack calculations.  Right now the
//       combat ends with the immediate destruction of the defending
//       unit (horribly basic, but good enough for now).
// Released on 2005-12-27 by scorbett
//     - "milestone 3" - demonstration of animation and (basic) combat.
//     - Details at TODO - update with URL when diary is posted
//-----------------------------------------------------------------------------

#include <vector>
#include <stdio.h> // for fopen, etc
#include <string.h> // for memset()

#include "SDL.h"
#include "SDL_gfxPrimitives.h"
#include "Terrain.h"
#include "Unit.h"
#include "HexMap.h"
#include "Team.h"


//////////////////////////////////////////////////////////////////////
// CONSTRUCTORS
//////////////////////////////////////////////////////////////////////


// Constructs a map and prepares it for use.
//   dispSurface - where should we blit the rendered map?
//   dispArea - where in dispSurface should we blit the map?
//   gridWidth - number of hexagons wide
//   gridHeight - number of hexagons tall
//   hexagonWidth (optional) - pixel width of each hexagon 
//   hexagonHeight (optional) - pixel height of each hexagon
//   hexagonMargin (optional) - pixel margin between hexagons
//
// NOTE - this constructor assumes you don't want to use
//        any terrain tiles (the background of the map
//        can be influenced via SetMapBackgroundColour).
HexMap::HexMap(SDL_Surface* dispSurface, 
               SDL_Rect* dispArea, 
               Uint8 gridWidth, 
               Uint8 gridHeight,
               Uint8 hexagonWidth/*=DEFAULT_HEX_WIDTH*/, 
               Uint8 hexagonHeight/*=DEFAULT_HEX_HEIGHT*/, 
               Uint8 hexagonMargin/*=DEFAULT_HEX_MARGIN*/)
{
  // By default there is no error to report:
  errorMessage = NULL;
  
  // This constructor ensures we use no terrain information:
  terrain = NULL;
  terrainIndeces = NULL;

  // Pass all parameters to the Initialize routine:
  Initialize(dispSurface,dispArea,gridWidth,gridHeight,
             hexagonWidth,hexagonHeight,hexagonMargin);
}


// Constructs a terrained map and prepares it for use.
//   dispSurface - where should we blit the rendered map?
//   dispArea - where in dispSurface should we blit the map?
//   mapFile - name of a file containing map data.
//
// This constructor will attempt to read all relevant map properties
// from "mapFile".  The IsLoaded() method will return true or
// false to indicate how the load went.  If something went wrong,
// the GetLoadError() method can be used to get a descriptive
// error message.
//
// NOTE - terrain can be shown or hidden using the SetTerrainVisible()
//        method (default is to show it).
HexMap::HexMap(SDL_Surface* dispSurface, SDL_Rect* dispArea, char* mapFile)
{
  // By default there is no error to report:
  errorMessage = NULL;

  // If we cannot parse the map file, create a defaulted, non-terrained map:
  if (! ParseMapFile(mapFile))
  {
    terrain = NULL;
    terrainIndeces = NULL;
    Initialize(dispSurface,dispArea,10,10);
  }
    
  // Otherwise, initialize with the properties we read from the map file:
  else
    Initialize(dispSurface,dispArea,gridSizeX,gridSizeY,
               hexSizeX,hexSizeY,hexMargin); 
}


//////////////////////////////////////////////////////////////////////
// DESTRUCTOR
//////////////////////////////////////////////////////////////////////


// Destructor - performs any necessary cleanup.
HexMap::~HexMap()
{
  delete[] hexState;
  delete[] hexBorderPointsX;
  delete[] hexBorderPointsY;
  if (terrainIndeces)
    delete[] terrainIndeces;
  if (errorMessage)
    delete[] errorMessage;
  if (terrain)
    delete terrain;
  SDL_FreeSurface(bufferSurface);
}


//////////////////////////////////////////////////////////////////////
// PUBLIC METHODS
//////////////////////////////////////////////////////////////////////


// Returns true unless something went wrong when parsing the .map file
// specified in the constructor.  Use GetLoadError() to get a descriptive
// error message.  Note that if you created this HexMap instance using
// the other constructor (to make a non-terrained map), this method
// will always return true.
bool HexMap::IsLoaded()
{
  return errorMessage == NULL;
}
    

// Returns NULL if the map is properly loaded and ready to go.
// If something went wrong while loading the .map file, this method
// will return a descriptive string.
char* HexMap::GetLoadError()
{
  return errorMessage;
}


// Sets a colour that will be used to paint the background behind
// the map.  (This is generally only useful if you aren't using
// terrain tiles, or if the map is smaller than the display area).
void HexMap::SetMapBackgroundColour(Uint8 r, Uint8 g, Uint8 b)
{
  // Map the given colour to something we can use with our buffer:
  mapBackgroundColour = SDL_MapRGB(bufferSurface->format,r,g,b);
  
  // Map the colour to something we can use on the display surface:
  displayBackgroundColour = SDL_MapRGB(displaySurface->format,r,g,b);
}


// Sets an image that will be used as an explosion animation.
// Multiple frames can be provided by making the image
// "imgWidth"*numFrames wide.
void HexMap::SetExplosionAnim(SDL_Surface* surface, Uint8 imgWidth)
{
  explosionSurface = surface;
  explosionAnimWidth = imgWidth;
  explosionFrames = surface->w / imgWidth;
}


// Specifies whether or not you want to show movement costs when
// displaying a movement radius.  This is for debugging purposes,
// and will probably be removed for the final product. 
// Looks neat though.
void HexMap::SetMovementCostVisible(bool visible)
{
  showMovementCost = visible;
}


// Tells the map what the default hexagon state is. 
// This is typically NO_BORDER, but you can change it to
// NORMAL if you want to see the grid.
void HexMap::SetDefaultHexState(HexState state)
{
  defaultHexState = state;
}


// Tells the map whether or not to render the terrain tiles.  
// If the map was constructed without terrain information, then
// this method does nothing.
void HexMap::SetTerrainVisible(bool isVisible)
{
  showTerrain = isVisible;
}


// Returns true if the hexagon at the given grid co-ordinates is
// currently visible (may be false if the map is scrolled somewhere
// else at the moment).
bool HexMap::IsHexVisible(Uint8 gridX, Uint8 gridY)
{
  // Convert grid x,y into pixel x,y
  int pixelX,pixelY;
  if (! GridToPixel(gridX,gridY,&pixelX,&pixelY))
    return false;

  // If the hex is completely outside the display area,
  // we'll call it invisible:
  if (pixelX < (scrollX - hexSizeX*2))
    return false;
  if (pixelX > (scrollX + displayArea.w))  
    return false;
  if (pixelY < (scrollY - hexSizeY*2))
    return false;
  if (pixelY > (scrollY + displayArea.h))
    return false;
    
  // If we survived the above checks, must be visible:
  return true;
}


// Returns the current border state of the hexagon
// at the given grid co-ordinates:
HexState HexMap::GetHexState(Uint8 gridX, Uint8 gridY)
{
  // Convert 2D co-ordinates into 1D index:
  int index = (gridY*gridSizeX)+gridX;
  
  // If the given index is out of bounds, return
  // NO_BORDER as a failsafe value 
  if (index < 0 || index >= gridSizeX*gridSizeY)
    return NO_BORDER; 
    
  // Otherwise, look up and return the border state:
  return hexState[index];
}


// Sets all hexagons to the given border state:
void HexMap::SetAllHexState(HexState state)
{
  // Set the whole state array to the given value:
  memset(hexState,state,gridSizeX*gridSizeY*sizeof(HexState));
}


// Sets the border state of the hexagon at the given
// grid-co-ordinates:
void HexMap::SetHexState(Uint8 gridX, Uint8 gridY, HexState state)
{
  // Convert 2D co-ordinates into 1D index:
  int index = (gridY*gridSizeX)+gridX;
  
  // Only attempt to set the state if our index is in bounds:
  if (index >= 0 && index < gridSizeX*gridSizeY)
    hexState[index] = state;
}


// Sets the border state of the hexagon at the
// given pixel co-ordinates:
void HexMap::SetHexStateByPixel(int pixelX, int pixelY, HexState state)
{
  Uint8 gridX,gridY;
  if (! PixelToGrid(pixelX,pixelY,&gridX,&gridY))
    return;
      
  SetHexState((Uint8)gridX,(Uint8)gridY,state);
}

    
// Returns the current state of the map.  If the current state is
// anything other than READY, user input is ignored.
MapState HexMap::GetMapState()
{
  return mapState;
}


// Sets the rate of speed at which units move from hexagon to
// hexagon during unit movement animations.  See the comment
// for DEFAULT_UNIT_MOVEMENT_RATE for details.
void HexMap::SetUnitMovementRate(Uint8 rate)
{
  unitMovementRate = rate;
}

    
// Sets the number of milliseconds that must elapse with no 
// cursor activity before the cursor is hidden.  Value is 
// in milliseconds.  A value of 0 means never hide the cursor.
void HexMap::SetCursorTimeout(int newTimeout)
{
  lastCursorTick = 0;
  cursorTimeout = newTimeout;
}


// Scrolls the map by the given amount.
// (values can be positive for scrolling right/down
//  or negative for scrolling left/up).
// Values are in pixels.
// This method does nothing if the display area is larger than the map.
void HexMap::ScrollBy(int deltaX, int deltaY)
{
  scrollX += deltaX;
  scrollY += deltaY;
  CheckScrollPosition();
}


// Immediately changes the scroll position to the given pixel
// co-ordinates.  
// This method does nothing if the display area is larger than the map.
void HexMap::ScrollTo(int newX, int newY)
{
  scrollX = newX;
  scrollY = newY;
  CheckScrollPosition();
}


// Changes the map scroll position (if necessary) so that the
// hexagon at the given grid co-ordinates is centered.
// This method does nothing if the display area is larger than the map.
void HexMap::CenterOnHex(Uint8 gridX, Uint8 gridY)
{
  // Convert grid co-ordinates to pixel co-ordinates:
  int pixelX,pixelY;
  if (! GridToPixel(gridX,gridY,&pixelX,&pixelY))
    return;
  
  // Subtract half the map size:
  pixelX -= displayArea.w/2 - hexCellWidth/2;
  pixelY -= displayArea.h/2 - hexSizeY/2;
  
  // Jump to this position:
  ScrollTo(pixelX,pixelY);
}


// Dynamically changes the display area where the rendered map should
// be blitted.  This can be called at any time (typically when your
// window is resized, but whatever).  
void HexMap::ResizeDisplayArea(SDL_Rect* newDisplayArea)
{
  // Accept the new display area (may be adjusted before we're done here:
  displayArea.w = newDisplayArea->w;
  displayArea.h = newDisplayArea->h;
  displayArea.x = newDisplayArea->x;
  displayArea.y = newDisplayArea->y;
  
  // Make a backup copy (we won't screw with this one):
  originalDisplayArea.w = newDisplayArea->w;
  originalDisplayArea.h = newDisplayArea->h;
  originalDisplayArea.x = newDisplayArea->x;
  originalDisplayArea.y = newDisplayArea->y;
  
  // If the grid is smaller than the display area, adjust the display
  // area so that the grid shows up centered:
  if (mapPixelWidth < displayArea.w)
  {
    displayArea.x = (displayArea.w-mapPixelWidth)/2 + displayArea.x;
    displayArea.w = mapPixelWidth;
  }
  if (mapPixelHeight < displayArea.h)
  {
    displayArea.y = (displayArea.h-mapPixelHeight)/2 + displayArea.y;
    displayArea.h = mapPixelHeight;
  }

  // The above calculations may have altered our current scroll position:
  CheckScrollPosition();
}


// Adds the given unit at the given co-ordinates:
void HexMap::AddUnit(Unit* unit, Uint8 gridX, Uint8 gridY)
{
  unitList.push_back(unit);
  unit->SetLocation(gridX,gridY);
}


// Selects the given unit.  If you specify NULL as the unit, 
// this method will unselect any currently selected unit.
void HexMap::SelectUnit(Unit* unit)
{
  // Only one unit can be selected at a time.  So, if there
  // was a unit already selected, unselect it:
  if (selectedUnit)
  {
    SetHexState(selectedUnit->GetGridX(),selectedUnit->GetGridY(),NO_BORDER);
    
    // If its movement radius was showing, cancel it:
    if (currentMovementRadius)
    {
      DeallocateMovementRadius(currentMovementRadius);
      currentMovementRadius = NULL;
    }
    
    // If its target radius was showing, cancel it:
    if (currentTargetRadius)
    {
      DeallocateTargetRadius(currentTargetRadius);
      currentTargetRadius = NULL;
    }
  }
  
  // Select this unit:
  selectedUnit = unit;
  
  // If the given unit exists, highlight it:
  if (selectedUnit)
  {
    SetHexState(selectedUnit->GetGridX(),selectedUnit->GetGridY(),
                 HIGHLIGHTED);
                 
    // Also show its current movement radius:
    currentMovementRadius = FindMovementRadius(selectedUnit);
    
    // Also show its current target radius:
    currentTargetRadius = FindTargetRadius(selectedUnit);
  }
}


// Renders the map and displays it.
void HexMap::DrawMap()
{
  // Fill the display buffer with our background colour:
  SDL_Rect rect;
  rect.x = 0;
  rect.y = 0;
  rect.w = mapPixelWidth;
  rect.h = mapPixelHeight;
  SDL_FillRect(bufferSurface,&rect,mapBackgroundColour);
  
  // Also fill the display area with the map background colour:
  // (explanation: this may seem redundant with the above step, but
  //  in fact it is not - at least, not in the case where the map is 
  //  smaller than the display area.  In that case, we need to fill
  //  the *original* display area, the one that was given to us by
  //  the caller.  The above call won't do that in this case because
  //  we adjusted our display area to center the map).
  SDL_FillRect(displaySurface,&originalDisplayArea,displayBackgroundColour);

  // Set all hexagons back to their default state:
  SetAllHexState(defaultHexState);
  
  // Highlight the current unit, if there is one:
  if (selectedUnit)
    SetHexState(selectedUnit->GetGridX(),selectedUnit->GetGridY(),
                 HIGHLIGHTED);
    
  // Is there a movement radius currently showing?
  if (currentMovementRadius)
    ShowMovementRadius(currentMovementRadius); 
    
  // Is there a target radius currently showing?
  if (currentTargetRadius)
    ShowTargetRadius(currentTargetRadius);
    
  // Is the cursor visible?
  if (lastCursorTick > 0)
  {
    // Has the cursor timed out?
    if (cursorTimeout > 0 &&
        (SDL_GetTicks() - lastCursorTick) >= cursorTimeout)
    {
      lastCursorTick = 0;
      SetHexState(cursorX,cursorY,NO_BORDER);
      cursorX = INVALID_CURSOR;
      cursorY = INVALID_CURSOR;      
    }
    
    // Otherwise, draw the cursor:
    else
      SetHexState(cursorX,cursorY,CURSOR);
  }
  
  // Update the position of any unit that is currently moving:
  if (unitMovementInfo)
  {
    ShowGridPath(unitMovementInfo->gridPath);   
    UpdateUnitMovement();
  }
    
  // Draw each hexagon:
  // (NOTE - this must be done before the units are drawn else
  //         our terrain will overdraw the unit sprites).
  for (Uint8 y = 0; y < gridSizeY; y++)
    for (Uint8 x = 0; x < gridSizeX; x++)
      DrawHex(x,y);      

  // Draw any explosions in progress:
  if (explosionInfo)
    UpdateExplosion();
      
  // Draw each unit:
  for (int i = 0; i < unitList.size(); i++)
  {
    Unit* unit = unitList[i];
  
    // If the unit is moving, skip it:
    if (unit->IsMoving())
      continue;
    
    // Convert grid x,y into pixel x,y
    int pixelX,pixelY;
    if (! GridToPixel(unit->GetGridX(),unit->GetGridY(),&pixelX,&pixelY))
      continue;
    
    // Draw this unit:
    unitList.at(i)->Draw(bufferSurface,pixelX,pixelY);
  }
  
  // If there's a unit currently being moved, draw it:
  // (explanation: this is handled separately from the above loop
  //  because moving units must be drawn at their current pixel
  //  location and NOT at their current grid location - otherwise
  //  the animation would look jerky.)
  if (unitMovementInfo)
  {
    unitMovementInfo->movingUnit->Draw(bufferSurface,
                              unitMovementInfo->currentPixelX,
                              unitMovementInfo->currentPixelY);
  }
  
  // DEBUG: Show movement costs if requested:
  if (showMovementCost && currentMovementRadius)
    ShowMovementCost(currentMovementRadius);
    
  // Fill any hexagons if required.
  // (NOTE - this must be done AFTER the units are drawn, unlike DrawHex,
  //         else the transparency will not work - i.e. we want the units
  //         to be drawn underneath the fill).
  for (Uint8 y = 0; y < gridSizeY; y++)
    for (Uint8 x = 0; x < gridSizeX; x++)
      FillHex(x,y);      
  
  // Compute source rectangle:
  SDL_Rect sourceRect;
  sourceRect.x = scrollX;
  sourceRect.y = scrollY;
  sourceRect.w = displayArea.w;
  sourceRect.h = displayArea.h;
  
  // Now blit the rendered map:
  SDL_BlitSurface(bufferSurface,&sourceRect,displaySurface,&displayArea);
}


// Called to simulate a mouse left click at the given pixel location:
void HexMap::LeftClick(int pixelX, int pixelY)
{
  // If we are not in the READY state, ignore this message:
  if (mapState != READY)
    return;
  
  Uint8 gridX,gridY;
  if (! PixelToGrid(pixelX,pixelY,&gridX,&gridY))
    return;
  
  // If the click was on a unit, select that unit:  
  // (Note we also make sure the clicked unit is on the right team)
  Unit* clickedUnit = GetUnitAt(gridX,gridY);
  if (clickedUnit && clickedUnit->GetTeamID() == currentTeam)
    SelectUnit(clickedUnit);
  
  // If the click was not on a unit, but we do have a selected unit and
  // a current movement radius, then the click may have been a movement
  // request or an attack request:
  if (! clickedUnit && selectedUnit && currentMovementRadius)
  {
    // If the click was inside the current movement radius, move the
    // selected unit to that grid cell:
    if (FindRadiusNode(currentMovementRadius,gridX,gridY))
    {
      DeallocateMovementRadius(currentMovementRadius);
      currentMovementRadius = NULL;
      InitiateUnitMovement(selectedUnit,gridX,gridY);
    }
  }
  
  if (clickedUnit && clickedUnit->GetTeamID() != currentTeam)
  {
    // Combat?
    if (currentTargetRadius)
    {
      // If the click was on a targetted hexagon, initiate combat:
      if (FindTargetNode(currentTargetRadius,gridX,gridY))
        DoCombat(currentTargetRadius->targettingUnit,clickedUnit);
    }
  }
  
  // This also counts as cursor activity:
  Cursor(pixelX,pixelY);
}

    
// Called to simulate a right mouse click at the given pixel location:
void HexMap::RightClick(int pixelX, int pixelY)
{
  // If we are not in the READY state, ignore this message:
  if (mapState != READY)
    return;
  
  // Deselect any selected unit (this will also hide any currently
  // displaying movement radius):
  SelectUnit(NULL);
}

    
// Called to simulate mouse/cursor movement at the given pixel location:
void HexMap::Cursor(int pixelX, int pixelY)
{
  // If we are not in the READY state, ignore this message:
  if (mapState != READY)
    return;
  
  Uint8 gridX,gridY;
  if (! PixelToGrid(pixelX,pixelY,&gridX,&gridY))
    return;

  // If the cursor was visible somewhere else, erase it:
  if (cursorX != INVALID_CURSOR && cursorY != INVALID_CURSOR &&
      (cursorX != gridX || cursorY != gridY))
    SetHexState(cursorX,cursorY,NO_BORDER);
    
  // Accept new location:
  cursorX = gridX;
  cursorY = gridY;  
  
  // Reset the cursor timeout:
  lastCursorTick = SDL_GetTicks();
}

    
// Returns the ZOC of a given hexagon.  In the case of hexagons that are
// that are overlapped (i.e. adjacent to multiple units of differing
// teams), the return value will be an OR'd combination of team codes.
Uint8 HexMap::GetZOC(Uint8 gridX, Uint8 gridY)
{
  // Otherwise, we're going to have to compile a list of adjacent units:
  Uint8 zoc = NEUTRAL_TEAM;
  Uint8 leftLimit = (gridX == 0) ? gridX : gridX - 1;
  Uint8 topLimit = (gridY == 0) ? gridY : gridY - 1;
  for (Uint8 x = leftLimit; x <= gridX+1; x++)
  {
    // Skip if we've gone off the grid:
    if (x >= gridSizeX)
      continue;
      
    for (Uint8 y = topLimit; y <= gridY+1; y++)
    {
      // Skip if we've gone off the grid:
      if (y >= gridSizeY)
        continue;
        
      // Skip non-adjacent hexagons:
      if (! AreHexagonsAdjacent(x,y,gridX,gridY))
        continue;
        
      // If there's a unit here, get its team id:
      Unit* candidateUnit = GetUnitAt(x,y);
      if (candidateUnit)
      {
        // If we've not yet seen a unit, just take this guy's team id:
        if (zoc == NEUTRAL_TEAM)
          zoc = candidateUnit->GetTeamID();
          
        // Otherwise, OR this guy in:
        else
          zoc |= candidateUnit->GetTeamID();
      }
    }
  }
  
  // Return the zoc that we've calculated above:
  return zoc;
}


// Returns a pointer to the unit that occupies the given hexagon, or
// NULL if there isn't a unit sitting there:
Unit* HexMap::GetUnitAt(Uint8 gridX, Uint8 gridY)
{
  for (int i = 0; i < unitList.size(); i++)
  {
    Unit* unit = unitList[i];
    if (unit->GetGridX() == gridX && unit->GetGridY() == gridY)
      return unit;
  }
  
  return NULL;
}

    
// Sets the "current" team.  Only one team can give orders at a time.
void HexMap::SetCurrentTeam(Uint8 team)
{
  currentTeam = team;
}


//////////////////////////////////////////////////////////////////////
// INTERNAL METHODS
//////////////////////////////////////////////////////////////////////


// Internal method to move the given unit from the given start location
// to the given destination.  The movement will be animated by 
// UpdateMovement() and terminates automatically once the unit
// has reached its destination.  During the move, the map state is
// set to UNIT_MOVING and no user input is allowed.
void HexMap::InitiateUnitMovement(Unit* unit, Uint8 gridDestX, Uint8 gridDestY)
{
  // If we are already moving, ignore this call.
  // The rules of the game are that only one unit can move at a time.
  // Note that if this map code is ever re-used in some other game,
  // we'd have to smarten this up a bit:
  if (mapState == UNIT_MOVING)
    return;

  // If there was a target radius visible, kill it now:
  if (currentTargetRadius)
  {
    DeallocateTargetRadius(currentTargetRadius);
    currentTargetRadius = NULL;
  }
    
  // Begin unit movement:
  mapState = UNIT_MOVING;
  unit->SetIsMoving(true);
  unitMovementInfo = new UnitMovementInfo;
  unitMovementInfo->movingUnit = unit;
  unitMovementInfo->gridDestX = gridDestX;
  unitMovementInfo->gridDestY = gridDestY;
  int pixelX,pixelY;
  GridToPixel(unit->GetGridX(),unit->GetGridY(),&pixelX,&pixelY);
  unitMovementInfo->currentPixelX = pixelX;
  unitMovementInfo->currentPixelY = pixelY;
  
  // Calculate the grid path the unit will take:
  unitMovementInfo->gridPath = FindPath(unit,
                                        gridDestX,
                                        gridDestY);
  
  // Set state variables to initial values:
  unitMovementInfo->startTick = SDL_GetTicks();
  unitMovementInfo->currentNode = 0;
  unitMovementInfo->currentStep = 0;
}

        
// Internal method to update unit movement if it is currently taking place:
void HexMap::UpdateUnitMovement()
{
  // If we're not currently moving anything, abort:
  if (mapState != UNIT_MOVING)
    return;
    
  // Increment the current step and watch for overflows:
  unitMovementInfo->currentStep++;
  if (unitMovementInfo->currentStep >= unitMovementRate)
  {   
    // Move to the next node in the path.
    unitMovementInfo->currentStep = 0;
    unitMovementInfo->currentNode++;
    Uint8 lastNode = unitMovementInfo->gridPath->numPoints-1;
    if (unitMovementInfo->currentNode >= lastNode)
    {
      // We've arrived at the destination... terminate movement:
      TerminateUnitMovement();
      return;
    }
    
    // Otherwise, move to the next node in the path:
    int pixelX,pixelY;
    Uint8 currentNode = unitMovementInfo->currentNode;
    GridToPixel(unitMovementInfo->gridPath->pointsX[currentNode],
                unitMovementInfo->gridPath->pointsY[currentNode],
                &pixelX,&pixelY);
    unitMovementInfo->currentPixelX = pixelX;
    unitMovementInfo->currentPixelY = pixelY;
  }
  
  // Calculate the deltaX and deltaY (in hexagons) that we are
  // moving this step:
  Uint8 currentNode = unitMovementInfo->currentNode;
  Uint8 currentGridX = unitMovementInfo->gridPath->pointsX[currentNode];
  Uint8 currentGridY = unitMovementInfo->gridPath->pointsY[currentNode];
  Uint8 nextGridX = unitMovementInfo->gridPath->pointsX[currentNode+1];
  Uint8 nextGridY = unitMovementInfo->gridPath->pointsY[currentNode+1];
  Sint8 gridDeltaX = nextGridX-currentGridX; // may be negative
  Sint8 gridDeltaY = nextGridY-currentGridY; // may be negative
  
  // Calculate the deltaX and deltaY we will apply to the current
  // pixel location of the unit:
  double pixelDeltaX = 0; // (gridDeltaX*hexCellWidth)/unitMovementRate;
  double pixelDeltaY = 0; // (gridDeltaY*hexSizeY)/unitMovementRate;
  
  // Straight vertical motion is easy:
  if (gridDeltaY != 0 && gridDeltaX == 0)
    pixelDeltaY = (gridDeltaY*hexSizeY)/unitMovementRate;
  
  // There is no straight horizontal motion because of our
  // hexagonal layout... we can only move diagonally:
  if (gridDeltaX != 0)
  {
    pixelDeltaX = (gridDeltaX*hexCellWidth)/unitMovementRate;
    
    Uint8 curX = unitMovementInfo->gridPath->pointsX[currentNode];
    Uint8 nextX = unitMovementInfo->gridPath->pointsX[currentNode+1];
    bool isStaggered = ((curX % 2) != 0);
    if (isStaggered)
    {
      if (gridDeltaY > 0)
        pixelDeltaY += (hexSizeY/2) / unitMovementRate;
      else
        pixelDeltaY -= (hexSizeY/2) / unitMovementRate;
    }
    else
    {
      if (gridDeltaY < 0)
        pixelDeltaY -= (hexSizeY/2) / unitMovementRate;
      else
        pixelDeltaY += (hexSizeY/2) / unitMovementRate;
    }
  }
  
  // Apply that to our current location and we're done:
  unitMovementInfo->currentPixelX += (Sint8)pixelDeltaX;
  unitMovementInfo->currentPixelY += (Sint8)pixelDeltaY;
}
 
       
// Internal method invoked automatically by UpdateUnitMovement when a unit
// has arrived at its destination.
void HexMap::TerminateUnitMovement()
{
  unitMovementInfo->movingUnit->SetIsMoving(false);
  unitMovementInfo->movingUnit->SetLocation(unitMovementInfo->gridDestX,
                                            unitMovementInfo->gridDestY);
  mapState = previousMapState; // restore state before move
  DeallocateGridPath(unitMovementInfo->gridPath);
  delete unitMovementInfo;
  unitMovementInfo = NULL;
  
  // Now that the move is complete, calculate a new target radius for
  // the selected unit:
  if (selectedUnit)
    currentTargetRadius = FindTargetRadius(selectedUnit);
}


// Internal method invoked as necessary by DoCombat to signal the start
// of an explosion animation.
void HexMap::StartExplosion(Uint8 gridX, Uint8 gridY)
{
  previousMapState = mapState; // store current map state
  mapState = EXPLOSION_ANIM;
  
  // Deselect any currently selected unit.  This will also
  // cancel any currently showing movement radius or target radius:
  SelectUnit(NULL);
  
  explosionInfo = new ExplosionInfo;
  int pixelX,pixelY;
  GridToPixel(gridX,gridY,&pixelX,&pixelY);
  explosionInfo->pixelX = pixelX;
  explosionInfo->pixelY = pixelY;
  explosionInfo->startTick = SDL_GetTicks();
  explosionInfo->currentFrame = 0;
}


// Internal method to update any currently animated explosion.
void HexMap::UpdateExplosion()
{
  // If we aren't currently exploding, abort:
  if (mapState != EXPLOSION_ANIM)
    return;
    
  // If we don't have an explosion image, I guess we're done.
  if (! explosionSurface)
  {
    TerminateExplosion();
    return;
  }
  
  // Update timer:
  if ((SDL_GetTicks() - explosionInfo->startTick) > EXPLOSION_TIMEOUT)
  {
    explosionInfo->startTick = SDL_GetTicks();
    explosionInfo->currentFrame++;
    if (explosionInfo->currentFrame >= explosionFrames)
    {
      TerminateExplosion();
      return;
    }
  }
  
  // Reset all hexagon states (gets rid of the mouse cursor as well)
  SetAllHexState(defaultHexState);
  
  // Compute source rect:
  SDL_Rect sourceRect;
  sourceRect.x = explosionInfo->currentFrame * explosionAnimWidth;
  sourceRect.y = 0;
  sourceRect.w = explosionAnimWidth;
  sourceRect.h = explosionSurface->h;
  
  // Compute dest rect:
  SDL_Rect destRect;
  destRect.x = explosionInfo->pixelX;
  destRect.y = explosionInfo->pixelY;
  
  // Draw it:
  SDL_BlitSurface(explosionSurface,&sourceRect,bufferSurface,&destRect);
}

    
// Internal method to stop an explosion animation when finished.
void HexMap::TerminateExplosion()
{
  if (mapState != EXPLOSION_ANIM)
    return;
    
  delete explosionInfo;
  explosionInfo = NULL;
  mapState = previousMapState;
}
    
    
// Internal method to handle combat between the two given units.
void HexMap::DoCombat(Unit* attackingUnit, Unit* defendingUnit)
{
  // TODO - this method needs work (obviously).
  //
  // For now, we'll handle combat by destroying the defending unit.
  // This is obviously pretty stupid but it is satisfactory for now
  // as it allows us to test out the interface a bit before enhancing it.
  
  // Boom!
  StartExplosion(defendingUnit->GetGridX(),defendingUnit->GetGridY());
  
  // Remove the defending unit from consideration:
  std::vector<Unit*>::iterator i;
  for (i = unitList.begin(); i != unitList.end(); i++)
  {
    if (*i == defendingUnit)
    {
      unitList.erase(i);
      break;
    }
  }
}
            

// Internal method to draw the hexagon at the given grid co-ordinates.
void HexMap::DrawHex(Uint8 gridX, Uint8 gridY)
{
  // If this hex is outside the display area, don't bother:
  if (! IsHexVisible(gridX,gridY))
    return;

  // Get hex state (highlighted, normal, etc)
  HexState state = GetHexState(gridX,gridY);
  
  // Convert grid x,y into pixel x,y
  int pixelX,pixelY;
  if (! GridToPixel(gridX,gridY,&pixelX,&pixelY))
    return;
  
  // If terrain is enabled and available, show it:
  if (showTerrain && terrain != NULL && terrainIndeces != NULL)
  {
    Uint8 terrainTile = terrainIndeces[gridY*gridSizeX+gridX];
    terrain->DrawTerrainTile(bufferSurface,pixelX,pixelY,terrainTile);
  }
  
  // If no border required, we're finished here:
  if (state == NO_BORDER)
    return;
  
  // Hard coding colour values for now:
  int colour = 0x777777FF; // NORMAL
  if (state == HIGHLIGHTED)
    colour = 0xFFFFFFFF;
  else if (state == CURSOR)
    colour = 0xFFFFFFFF;
  else if (state == TARGETTED)
    colour = 0xFF0000FF;
    
  // Compute points of this hex:
  // (explanation: we have already precomputed what our hexagon
  //  looks like, but we need to add the current pixel location
  //  to those hexagon points)
  short XPoints[6];
  short YPoints[6];
  for (int i = 0; i < 6; i++)
  {
    XPoints[i] = pixelX + hexBorderPointsX[i];
    YPoints[i] = pixelY + hexBorderPointsY[i];
  }
    
  // Draw this hex:
  /*aa*/polygonColor(bufferSurface,XPoints,YPoints,6,colour);
}


// Internal method to fill the hexagon (if necessary) at the given
// grid co-ordinates.  Whether or not a fill is performed is dependent
// upon the HexState of the given hexagon.
void HexMap::FillHex(Uint8 gridX, Uint8 gridY)
{
  // If this hex is outside the display area, don't bother:
  if (! IsHexVisible(gridX,gridY))
    return;

  // Get hex state (highlighted, normal, etc)
  HexState state = GetHexState(gridX,gridY);
  
  // If no fill is required, we're finished here:
  if (state != TARGETTED && state != CURSOR)
    return;
  
  // Convert grid x,y into pixel x,y
  int pixelX,pixelY;
  if (! GridToPixel(gridX,gridY,&pixelX,&pixelY))
    return;

  // Compute points of this hex:
  // (explanation: we have already precomputed what our hexagon
  //  looks like, but we need to add the current pixel location
  //  to those hexagon points)
  short XPoints[6];
  short YPoints[6];
  for (int i = 0; i < 6; i++)
  {
    XPoints[i] = pixelX + hexBorderPointsX[i];
    YPoints[i] = pixelY + hexBorderPointsY[i];
  }
  
  // Hard coding colour for now:    
  int alphaColour = 0xFF000044; // TARGETTED
  if (state == CURSOR)
    alphaColour = 0xFFFFFF33;;
  
  // We may have a state where the given hexagon is CURSOR
  // and TARGETTED - in this case, we'll show a white border
  // and a red fill:  
  if (state == CURSOR && currentTargetRadius)
  {
    if (FindTargetNode(currentTargetRadius,gridX,gridY))
    {
      polygonColor(bufferSurface,XPoints,YPoints,6,0xFFFFFFFF);
      alphaColour = 0xFF000044;
    }
  }
    
  // Fill the hex:
  filledPolygonColor(bufferSurface,XPoints,YPoints,6,alphaColour);
}


// Internal method called by ScrollBy and ScrollTo.
// If the map has scrolled too far in any direction, this method
// will keep it in check.
void HexMap::CheckScrollPosition()
{
  if (scrollX >= (mapPixelWidth-displayArea.w))
    scrollX = mapPixelWidth-displayArea.w;
  if (scrollY >= (mapPixelHeight-displayArea.h))
    scrollY = mapPixelHeight-displayArea.h;
  if (scrollX < 0) scrollX = 0;
  if (scrollY < 0) scrollY = 0;
}


// Internal method to parse out the specified map file.  Called only
// from the constructor.
bool HexMap::ParseMapFile(char* mapFile)
{
  FILE* inFile = fopen(mapFile,"rb");
  if (! inFile)
  {
    errorMessage = new char[100];
    strcpy(errorMessage,"Unable to open specified map file.");
    return false;
  }
  
  // Ensure the version is one we recognize:
  Uint8 Version;
  fread(&Version,sizeof(Uint8),1,inFile);
  if (Version != 1)
  {
    fclose(inFile);
    errorMessage = new char[100];
    strcpy(errorMessage,"Unrecognized map file version.");
    return false;
  }
  
  // Get the grid dimensions:
  Uint8 gridX,gridY;
  fread(&gridX,sizeof(Uint8),1,inFile);
  fread(&gridY,sizeof(Uint8),1,inFile);
  if (gridX < 1 || gridX > MAX_GRID_SIZE_X || 
      gridY < 1 || gridY > MAX_GRID_SIZE_Y)
  {
    fclose(inFile);
    errorMessage = new char[100];
    strcpy(errorMessage,"Invalid grid dimensions in map file.");
    return false;
  }
  gridSizeX = gridX;
  gridSizeY = gridY;

  // Get the name of the terrain meta file:
  Uint8 stringLength;
  fread(&stringLength,sizeof(Uint8),1,inFile);
  if (stringLength == 0)
  {
    fclose(inFile);
    errorMessage = new char[100];
    strcpy(errorMessage,"Map file does not specify any terrain data.");
    return false;
  }
  char* terrainMetaFile = new char[stringLength+1];
  fread(terrainMetaFile,sizeof(char),stringLength,inFile);
  terrainMetaFile[stringLength] = '\0';
  
  // Parse the terrain meta file:
  terrain = new Terrain(terrainMetaFile);
  
  // Ensure the terrain loaded okay:
  if (! terrain->IsLoaded())
  {
    fclose(inFile);
    errorMessage = new char[100];
    strcpy(errorMessage,terrain->GetLoadError());
    delete terrain;
    return false;
  }
  
  // Get the relevant properties out of it:
  hexSizeX = terrain->GetHexSizeX();
  hexSizeY = terrain->GetHexSizeY();
  hexMargin = terrain->GetHexMargin();
    
  // Read the actual map data (terrain indeces).
  terrainIndeces = new Uint8[gridSizeX*gridSizeY];
  fread(terrainIndeces,sizeof(Uint8),gridSizeX*gridSizeY,inFile);
  fclose(inFile);
  
  return true;
}


// Internal method to set up the class properties - this is only invoked
// from the constructors and is only invoked once.  For documentation
// of the parameters, see the constructors.
void HexMap::Initialize(SDL_Surface* dispSurface, SDL_Rect* dispArea,
       Uint8 gridWidth, Uint8 gridHeight,
       Uint8 hexagonWidth/*=DEFAULT_HEX_WIDTH*/, 
       Uint8 hexagonHeight/*=DEFAULT_HEX_HEIGHT*/,
       Uint8 hexagonMargin/*=DEFAULT_HEX_MARGIN*/)
{
  // Accept grid parameters:
  displaySurface = dispSurface;
  gridSizeX = (gridWidth < MAX_GRID_SIZE_X) ? gridWidth : MAX_GRID_SIZE_X;
  gridSizeY = (gridHeight < MAX_GRID_SIZE_Y) ? gridHeight : MAX_GRID_SIZE_Y;
  hexSizeX = hexagonWidth;
  hexSizeY = hexagonHeight;
  hexMargin = hexagonMargin;
  
  // Start by displaying map from upper left:
  scrollX = 0;
  scrollY = 0;

  // Arbitrary defaults:
  currentTeam = BLUE_TEAM;
  SetMovementCostVisible(false);
  
  // No selected unit yet:
  selectedUnit = NULL;
  
  // Default cursor timeout:
  SetCursorTimeout(DEFAULT_CURSOR_TIMEOUT);  
  
  // Default hexagon state:
  SetDefaultHexState(DEFAULT_HEX_STATUS);
  
  // Cursor not yet on the map:
  cursorX = INVALID_CURSOR;
  cursorY = INVALID_CURSOR;

  // Default unit movement rate:
  SetUnitMovementRate(DEFAULT_UNIT_MOVEMENT_RATE);
  
  // Movement not in progress:
  unitMovementInfo = NULL;
  currentMovementRadius = NULL;
  
  // Explosion not in progress:
  explosionInfo = NULL;
  explosionAnimWidth = 0;
  explosionFrames = 0;
  
  // No targetting yet:
  currentTargetRadius = NULL;
    
  // By default, terrain will be shown.
  // This can be toggled on/off via SetTerrainVisible().
  // If the map was constructed without terrain info,
  // then this flag does nothing.
  showTerrain = true;
    
  // The width of a hex is NOT the same as the width
  // of a grid cell.  Calculate the cell width and
  // store it:
  // (explanation: because of the honeycomb pattern, 
  //  the hexagons actually overlap each other horizontally.
  //  The amount of overlap is equal to half of the
  //  hexagon's height.)
  hexCellWidth = hexSizeX - hexSizeY/2; 
  
  // Calculate pixel width of map:
  mapPixelWidth = gridSizeX * hexCellWidth // width of all columns
                  + gridSizeX * hexMargin  // plus width of margins
                  + hexSizeY/2             // last column is full width
                  - hexMargin;             // last column has no margin
                  
  // Calculate pixel height of map:
  mapPixelHeight = gridSizeY * hexSizeY    // height of all rows
                   + gridSizeY * hexMargin // plus height of all margins
                   + hexSizeY/2;           // account for staggered columns

  // Set up our display area:
  // (this must be called after the above calculations because it
  //  references mapPixelWidth and mapPixelHeight).
  // This will also handle the centering of the map if it is
  // too small for the display area.
  ResizeDisplayArea(dispArea);
    
  // Create display buffer:
  // This code was pretty much copied+pasted from the SDL docs
  Uint32 rmask, gmask, bmask, amask;
  #if SDL_BYTEORDER == SDL_BIG_ENDIAN
    rmask = 0xff000000;
    gmask = 0x00ff0000;
    bmask = 0x0000ff00;
    amask = 0x00000000;
  #else
    rmask = 0x000000ff;
    gmask = 0x0000ff00;
    bmask = 0x00ff0000;
    amask = 0x00000000;
  #endif  
  bufferSurface = SDL_CreateRGBSurface(SDL_SWSURFACE,
                                       mapPixelWidth,
                                       mapPixelHeight,
                                       32,rmask,gmask,bmask,0);
  
  // Default background colour is black:
  // (this must be called after the bufferSurface is created because
  //  it references bufferSurface).
  SetMapBackgroundColour(0,0,0);  
    
  // By default, we don't show the borders around each hexagon.
  hexState = new HexState[gridSizeX*gridSizeY];
  SetAllHexState(NO_BORDER);
    
  // Precompute the hexagon border points for the draw polygon routine:
  // (explanation: this code was moved here from DrawHex as a bit of
  //  an optimization so that we don't re-compute the same basic points
  //  over and over.  These points can very quickly be added to a given
  //  pixel offset to draw a hex at any location).
  // 
  // Note on hexagon dimensions:
  //   Ideally, our hexagons should have 45 degree lines from the leftmost
  //   and rightmost points.  In order to guarantee a 45 degree angle, we
  //   use half the height of the hexagon as our base amount.  (picture a
  //   right angle triangle whose hypotenuse is one of the angled lines of
  //   our hexagon - the height of this triangle is half the height of the
  //   hexagon, so in order to make the hypotenuse a nice 45 degree angle,
  //   its length has to be the same length).
  //
  //   For this reason, our hexagons half to be wider than they are
  //   tall (otherwise the following calculations will result in a diamond
  //   shape, or worse).  We'll leave this as a (reasonable) burden on
  //   the caller.  Personally, I find a ratio of about 1.5:1 looks best.
  hexBorderPointsX = new Uint8[6];
  hexBorderPointsY = new Uint8[6];
  hexBorderPointsX[0] = 0;
  hexBorderPointsX[1] = hexSizeY/2; 
  hexBorderPointsX[2] = hexSizeX - hexSizeY/2;
  hexBorderPointsX[3] = hexSizeX-1;
  hexBorderPointsX[4] = hexSizeX - hexSizeY/2;
  hexBorderPointsX[5] = hexSizeY/2;
  hexBorderPointsY[0] = hexSizeY/2;
  hexBorderPointsY[1] = 0;
  hexBorderPointsY[2] = 0;
  hexBorderPointsY[3] = hexSizeY/2;
  hexBorderPointsY[4] = hexSizeY-1;
  hexBorderPointsY[5] = hexSizeY-1;
  
  // Default to READY status (i.e. accept user input):
  mapState = READY;
  previousMapState = READY;
}


// Internal method to convert the given pixel co-ordinates into 
// grid co-ordinates.  Returns false if the given pixel location
// is off the grid, true if the conversion succeeded.
bool HexMap::PixelToGrid(int pixelX, int pixelY, Uint8* gridX, Uint8* gridY)
{
  // Disregard requests that fall outside the display area:
  if (pixelX < displayArea.x || pixelX > displayArea.x+displayArea.w ||
      pixelY < displayArea.y || pixelY > displayArea.y+displayArea.h)
    return false;

  // Convert pixel x,y into grid x,y
  pixelX -= displayArea.x;
  pixelY -= displayArea.y;
  pixelX += scrollX;
  pixelY += scrollY;
  int theGridX = (Uint8)(pixelX/(hexCellWidth+hexMargin));
  int theGridY = (Uint8)(pixelY/(hexSizeY+hexMargin));
  
  // Take staggered hexagons into account:
  // (explanation: every other column is offset vertically by half
  //  the height of a hexagon.  This makes pixel to grid co-ordinate
  //  conversions tricky, because we have to do a bit of extra math
  //  if we're in a staggered column.  Basically, if the pixel x,y
  //  is in the upper half of what *should* be our hexagon, we decrement
  //  the gridY, because we're actually in the bottom half of the guy
  //  above us.  This decrement operation may cause gridY to go negative
  //  if we're at the top of the map, but that's okay because we
  //  do bounds checking immediately after this anyway).
  if (theGridX%2 != 0 && 
     (pixelY%(hexSizeY+hexMargin) <= (hexSizeY/2+hexMargin)))
    theGridY--;  
  
  // Protect from out of bounds cases (can happen if the mouse is near
  // the edge of the map):
  if (theGridX < 0 || theGridX >= gridSizeX || 
      theGridY < 0 || theGridY > gridSizeY)
    return false;
  
  // Set results and exit  
  *gridX = theGridX;
  *gridY = theGridY;
  return true;
}


// Internal method to convert the given grid co-ordinates into
// pixel co-ordinates.  Returns false if the given grid location
// is off the grid, true if the conversion succeeded.
bool HexMap::GridToPixel(Uint8 gridX, Uint8 gridY, int* pixelX, int* pixelY)
{
  if (gridX >= gridSizeX || gridY > gridSizeY)
    return false;
    
  *pixelX = gridX*hexCellWidth + gridX*hexMargin;
  *pixelY = gridY*hexSizeY + gridY*hexMargin;
  
  // Stagger this hex if necessary:
  // (explanation: every second column of hexagons is offset vertically
  //  by half the height of a single hex.  This gives us a nice honeycomb
  //  pattern instead of a straight grid).
  if (gridX%2 != 0)
    *pixelY += ((hexSizeY/2) + hexMargin/2);    
    
  return true;
}


// Internal method to estimate the distance (in grid units) between
// the given grid points. This is a rough estimate that will typically be
// a bit higher than the actual distance.
Uint8 HexMap::GetDistanceBetween(Uint8 x1, Uint8 y1, Uint8 x2, Uint8 y2)
{
  int deltaX = (x1 > x2) ? x1 - x2 : x2 - x1;
  int deltaY = (y1 > y2) ? y1 - y2 : y2 - y1;
  return deltaX + deltaY; // hardly accurate!
}


// Internal method to estimate the distance (in grid units) between
// the given GridPathNode objects.  This is a rough estimate that will 
// typically be a bit higher than the actual distance.
Uint8 HexMap::GetDistanceBetween(GridPathNode* startPoint, 
                                 GridPathNode* endPoint)
{
  return GetDistanceBetween(startPoint->gridX,startPoint->gridY,
                            endPoint->gridX,endPoint->gridY);
}

    
// Internal method to determine whether two hexagons are adjacent.
// This is not as straightforward as you might expect because of
// our staggered columns.  This method returns true if the two
// hexagons are adjacent (i.e. share a side).
bool HexMap::AreHexagonsAdjacent(Uint8 gridX1, Uint8 gridY1, 
                                 Uint8 gridX2, Uint8 gridY2)
{
  // If this is NOT a staggered column, we consider the following
  // cells "adjacent":
  //
  //       /---\
  //      /  x  \
  //  /---\ y-1 /---\
  // / x-1 \___/ x+1 \
  // \ y-1 /   \ y-1 /
  //  \___/     \___/
  //  /   \     /   \
  // / x-1 \___/ x+1 \
  // \  y  /   \  y  /
  //  \___/  x  \___/
  //      \ y+1 /
  //       \___/
  //
  if (gridX1%2 == 0)
  {
    if (gridX2 == gridX1-1 && gridY2 == gridY1+1)
      return false;
    if (gridX2 == gridX1+1 && gridY2 == gridY1+1)
      return false;
    if (gridX2 == gridX1 && gridY2 == gridY1)
      return false;
  }
      
  // If this IS a staggered column, we consider the following
  // cells "adjacent":
  //
  //       /---\
  //      /  x  \
  //  /---\ y-1 /---\
  // / x-1 \___/ x+1 \
  // \  y  /   \  y  /
  //  \___/     \___/
  //  /   \     /   \
  // / x-1 \___/ x+1 \
  // \ y+1 /   \ y+1 /
  //  \___/  x  \___/
  //      \ y+1 /
  //       \___/
  //
  else
  {
    if (gridX2 == gridX1-1 && gridY2 == gridY1-1)
      return false;
    if (gridX2 == gridX1+1 && gridY2 == gridY1-1)
      return false;
    if (gridX2 == gridX1 && gridY2 == gridY1)
      return false;
  }
  
  // If we survived the above, we're adjacent:
  return true;
}


// Internal method to highlight all the hexagons on the given GridPath.
void HexMap::ShowGridPath(GridPath* path)
{
  for (int i = 0; i < path->numPoints; i++)
    SetHexState(path->pointsX[i],path->pointsY[i],HIGHLIGHTED);
}

    
// Internal method to highlight all the hexagons in the
// given MovementRadius:
void HexMap::ShowMovementRadius(MovementRadius* radius)
{
  SetHexState(radius->unit->GetGridX(),radius->unit->GetGridY(),HIGHLIGHTED);
  for (int i = 0; i < radius->numPoints; i++)
    SetHexState(radius->pointsX[i],radius->pointsY[i],HIGHLIGHTED);
}


// Internal debug method to show the cost associated with moving to
// each hexagon in the given movement radius.
void HexMap::ShowMovementCost(MovementRadius* radius)
{  
  for (int i = 0; i < radius->numPoints; i++)
  {
    // Don't draw on the originating unit:
    if (radius->pointsX[i] == radius->unit->GetGridX() &&  
        radius->pointsY[i] == radius->unit->GetGridY())
      continue;
  
    int pixelX,pixelY;
    GridToPixel(radius->pointsX[i],radius->pointsY[i],&pixelX,&pixelY);
    pixelX += (hexSizeX/2) - 5;
    pixelY += (hexSizeY/2) - 4;
    char* tempStr = new char[100];
    sprintf(tempStr,"%d",radius->movementCost[i]/10);
    stringRGBA(bufferSurface,pixelX,pixelY,tempStr,0xFF,0xFF,0xFF,0xFF);
    delete[] tempStr;
  }
}


// Internal method to highlight all the hexagons in the given TargetRadius:
void HexMap::ShowTargetRadius(TargetRadius* radius)
{
  SetHexState(radius->targettingUnit->GetGridX(),
              radius->targettingUnit->GetGridY(),
              HIGHLIGHTED);
  for (Uint8 i = 0; i < radius->numTargets; i++)  
    SetHexState(radius->pointsX[i],radius->pointsY[i],TARGETTED);
}

    
// Internal function to find a GridPathNode in the given list and return it.
// If no such node was found, NULL is returned.  Matches are determined
// by comparing the gridX and gridY.
GridPathNode* HexMap::FindGridPathNode(std::vector<GridPathNode*>* nodeList, 
                                       GridPathNode* nodeToFind)
{
  for (int i = 0; i < nodeList->size(); i++)
  {
    GridPathNode* candidateNode = nodeList->at(i);
    if (candidateNode->gridX == nodeToFind->gridX &&
        candidateNode->gridY == nodeToFind->gridY)
      return candidateNode;
  }
  
  return NULL;
}


// Internal function to find a RadiusNode in the given list and return it.
// If no such node was found, NULL is returned.  Matches are determined
// by comparing the gridX and gridY.
RadiusNode* HexMap::FindRadiusNode(std::vector<RadiusNode*>* nodeList,
                                   RadiusNode* nodeToFind)
{
  for (int i = 0; i < nodeList->size(); i++)
  {
    RadiusNode* candidateNode = nodeList->at(i);
    if (candidateNode->gridX == nodeToFind->gridX &&
        candidateNode->gridY == nodeToFind->gridY)
      return candidateNode;
  }
  
  return NULL;  
}

    
// Internal method to report if a given hexagon is within the given
// movement radius or not.
bool HexMap::FindRadiusNode(MovementRadius* radius, Uint8 gridX, Uint8 gridY)
{
  for (int i = 0; i < radius->numPoints; i++)
  {
    if (radius->pointsX[i] == gridX && radius->pointsY[i] == gridY)
      return true;
  }
  
  // If we get this far, we're out of luck:
  return false;
}


// Internal method to report if a given hexagon is within the given
// target radius or not.
bool HexMap::FindTargetNode(TargetRadius* radius, Uint8 gridX, Uint8 gridY)
{
  for (int i = 0; i < radius->numTargets; i++)
  {
    if (radius->pointsX[i] == gridX && radius->pointsY[i] == gridY)
      return true;
  }
  
  return false;
}

    
// Internal method to release all memory associated with a GridPath:
void HexMap::DeallocateGridPath(GridPath* path)
{
  delete[] path->pointsX;
  delete[] path->pointsY;
  delete path;
}


// Internal method to release all memory associated with a movement radius:
void HexMap::DeallocateMovementRadius(MovementRadius* radius)
{
  delete[] radius->pointsX;
  delete[] radius->pointsY;
  delete radius;
}


// Internal method to release all memory associated with a target radius:
void HexMap::DeallocateTargetRadius(TargetRadius* radius)
{    
  delete[] radius->pointsX;
  delete[] radius->pointsY;
  delete radius;
}


// Internal method to find a path between two grid points and returns it.
// Return value will be NULL if no such path exists (i.e. the way is blocked
// by terrain).  Caller must delete the GridPath struct after using it.
// If "obeyTerrain" is true (default), terrain tiles will be taken into 
// account to slow or block movement.  If it is false (i.e. for flying units,
// terrain is ignored).
GridPath* HexMap::FindPath(Unit* movingUnit, Uint8 x2, Uint8 y2)
{
  // If the unit is a ground-based unit, we'll obey terrain features:
  bool obeyTerrain = (movingUnit->GetUnitType()==GROUND_UNIT);

  Uint8 x1 = movingUnit->GetGridX();
  Uint8 y1 = movingUnit->GetGridY();
  
  // stupid check:
  if (x1 == x2 && y1 == y2)
    return NULL;

  std::vector<GridPathNode*> openList;
  std::vector<GridPathNode*> closedList;
  
  // Create a node for our start position:
  GridPathNode* startNode = new GridPathNode;
  startNode->gridX = x1;
  startNode->gridY = y1;
  startNode->distanceFromStart = 0;
  startNode->distanceToEnd = GetDistanceBetween(x1,y1,x2,y2);
  startNode->parentNode = NULL;
  openList.push_back(startNode);  

  // Do the same for the end position:
  GridPathNode* endNode = new GridPathNode;
  endNode->gridX = x2;
  endNode->gridY = y2;
  endNode->distanceFromStart = startNode->distanceToEnd;
  endNode->distanceToEnd = 0;
  endNode->parentNode = NULL;

  // Find the path:
  bool searching = true;
  GridPathNode* theNode = NULL;
  GridPath* thePath = NULL;
  while (searching)
  {    
    // Search current open list:
    theNode = FindPath_EvaluateNode(startNode,endNode,
                                    movingUnit->GetMovementRadius()*10,
                                    movingUnit->GetTeamID(),
                                    &openList,&closedList,
                                    obeyTerrain);
    
    // If the open list is empty OR if we found something,
    // then we're done:
    if (theNode != NULL || openList.empty())
      searching = false;
  }

  // If we found a path, build up a GridPath object for return:
  if (theNode != NULL)
  {
    thePath = new GridPath;
    thePath->startX = x1;
    thePath->endX = x2;
    thePath->startY = y1;
    thePath->endY = y2;
    thePath->numPoints = 0;
    
    GridPathNode* curNode = theNode;    
    while (curNode != NULL)
    {    
      thePath->numPoints++;
      curNode = curNode->parentNode;
    }
    thePath->pointsX = new Uint8[thePath->numPoints];
    thePath->pointsY = new Uint8[thePath->numPoints];
    
    // Now add all the points:
    int currentIndex = thePath->numPoints-1;
    curNode = theNode;
    while (curNode != NULL)
    {
      thePath->pointsX[currentIndex] = curNode->gridX;
      thePath->pointsY[currentIndex] = curNode->gridY;
      currentIndex--;
      curNode = curNode->parentNode;
    }
  }
  
  // Deallocate all memory:
  delete endNode;
  for (int i = openList.size()-1; i >= 0; i--)
  {
    GridPathNode* node = openList.at(i);
    delete node;
    openList.pop_back();
  }
  for (int i = closedList.size()-1; i >= 0; i--)
  {
    GridPathNode* node = closedList.at(i);
    delete node;
    closedList.pop_back();
  }
  
  // Return results (this will be NULL if no path was found above):
  return thePath;
}

    
// Internal method that exists to support the FindPath method.  This method
// evaluates all the nodes in the given openList, picks the "best" one, then
// evaluates all of its neighbors.  Return value is NULL if the path has
// not yet been found, or the final step if the path is found.                       
GridPathNode* HexMap::FindPath_EvaluateNode(GridPathNode* startNode, 
                                        GridPathNode* endNode,
                                        int maximumRadius,
                                        Uint8 movingTeam,
                                        std::vector<GridPathNode*>* openList,
                                        std::vector<GridPathNode*>* closedList,
                                        bool obeyTerrain)
{
  // Search through the open list and find the node with the 
  // lowest "F" score (sum of distance from start and distance
  // to end).
  GridPathNode* bestNode = NULL;
  for (int i = 0; i < openList->size(); i++)
  {
    GridPathNode* candidateNode = openList->at(i);
    int F = candidateNode->distanceFromStart + candidateNode->distanceToEnd;
    if (bestNode == NULL)
    {
      bestNode = candidateNode;
    }
    else
    {
      if ((bestNode->distanceFromStart + bestNode->distanceToEnd) > F)
        bestNode = candidateNode;
    }
  }
  
  // If we found nothing, bail out:
  // (This means we have exhausted all possible paths)
  if (bestNode == NULL)
    return NULL;

  // Evaluate all neighbouring tiles... but be sure not
  // to go too far (if the path would take us off the map)
  for (int curX = (bestNode->gridX > 0) ? bestNode->gridX-1 : 0; 
           curX <= bestNode->gridX + 1; 
           curX++)
  {
    // Skip this one if we've gone off the map:
    if (curX >= gridSizeX)
      continue;
    
    for (int curY = (bestNode->gridY > 0) ? bestNode->gridY-1 : 0; 
             curY <= bestNode->gridY + 1; 
             curY++)
    {
      // Skip this one if we've gone off the map:
      if (curY >= gridSizeY)
        continue;
    
      // If this cell is not adjacent to the current node, skip it:
      if (! AreHexagonsAdjacent(bestNode->gridX,bestNode->gridY,curX,curY))
        continue;
      
      // If we are taking terrain into account, and if the given grid location
      // is impassable, skip it:
      int movementValue = 10; // TODO don't hard code this, also document it
      if (obeyTerrain && terrain != NULL && terrainIndeces != NULL)
      {
        int terrainIndex = terrainIndeces[curY*gridSizeX+curX];
        int movementValue = terrain->GetMovementValue(terrainIndex);
        if (movementValue == NO_MOVEMENT)
          continue;
      }

      // If the node is too far away, skip it:
      if (bestNode->distanceFromStart + movementValue > maximumRadius)
        continue;
      
      // If there's an enemy unit sitting there, forget it:
      Unit* enemyUnit = GetUnitAt(curX,curY);
      if (enemyUnit && enemyUnit->GetTeamID() != movingTeam)
        continue;
        
      // If the given hex is in an enemy ZOC, then you can enter it but
      // you can't move through it:
      Uint8 zoc = GetZOC(curX,curY);
      if (zoc & NEUTRAL_TEAM)
        zoc ^= NEUTRAL_TEAM; // Remove NEUTRAL team if present
      if (zoc & movingTeam)
        zoc ^= movingTeam; // remove friendly team if present
      if (zoc) // if anything's left, it's an enemy-controlled hex
        movementValue = maximumRadius - bestNode->distanceFromStart;
                    
      // If the node is too far away, skip it:
      if (bestNode->distanceFromStart + movementValue > maximumRadius)
        continue;      
                    
      // Create a node for this position:
      GridPathNode* newNode = new GridPathNode;
      newNode->gridX = curX;
      newNode->gridY = curY;
      newNode->distanceFromStart = bestNode->distanceFromStart + movementValue; // 1;
      newNode->distanceToEnd = GetDistanceBetween(newNode,endNode);
      newNode->parentNode = bestNode;

      // If this node is already closed, skip it:
      if (FindGridPathNode(closedList,newNode))
      {
        delete newNode;
        continue;
      }
            
      // If this node is already in the open list, modify it:
      GridPathNode* existingNode = FindGridPathNode(openList,newNode);
      if (existingNode)
      {
        if (newNode->distanceFromStart < existingNode->distanceFromStart)
        {
          existingNode->distanceFromStart = newNode->distanceFromStart;
          existingNode->parentNode = newNode->parentNode;
        }
        delete newNode; // we'll leave the existing one in there
      }
      
      // If this node was not yet in the open list, add it now:
      else
      {
        openList->push_back(newNode);
        
        // Check to see if we've hit our target:
        if (newNode->gridX == endNode->gridX && newNode->gridY==endNode->gridY)
          return newNode;
      }
    }        
  }
  
  // Move current node to closed list:
  std::vector<GridPathNode*>::iterator i;
  for (i = openList->begin(); i != openList->end(); i++)
  {
    if ((*i)->gridX == bestNode->gridX && 
        (*i)->gridY == bestNode->gridY)
    {
      openList->erase(i);
      break;
    }
  }
  if (! FindGridPathNode(closedList,bestNode))
    closedList->push_back(bestNode);
  else
    delete bestNode;
    
  return NULL;
}

 
// Internal method to find the movement radius of the given unit.  Terrain will
// be taken into account if the unit is a ground based unit (flying units are
// immune to terrain effects).  
MovementRadius* HexMap::FindMovementRadius(Unit* unit)
{
  bool obeyTerrain = (unit->GetUnitType() == GROUND_UNIT);
  int radius = unit->GetMovementRadius() * 10;
  
  // Create a node for the starting position:
  RadiusNode* startNode = new RadiusNode;
  startNode->gridX = unit->GetGridX();
  startNode->gridY = unit->GetGridY();
  startNode->costFromStart = 0;
  startNode->parentNode = NULL;
  
  // Create an open list and add the start node to it:
  std::vector<RadiusNode*> openList;
  openList.push_back(startNode);
  
  // Create an empty closed list which will store hexagons
  // that have already been considered:
  std::vector<RadiusNode*> closedList;
  
  // Evaluate neighboring hexagons until we have
  // exhausted the movement radius:  
  bool searching = true;
  while (searching)
  {
    searching = FindMovementRadius_EvaluateNode(radius,
                                                unit,
                                                startNode,
                                                &openList,
                                                &closedList,
                                                obeyTerrain);
  }
  
  // Create a radius struct and populate it:
  MovementRadius* movementRadius = NULL;
  if (closedList.size() > 0)
  {
    movementRadius = new MovementRadius;
    movementRadius->unit = unit;
    movementRadius->numPoints = closedList.size();
    movementRadius->pointsX = new Uint8[closedList.size()];
    movementRadius->pointsY = new Uint8[closedList.size()];
    movementRadius->movementCost = new Uint8[closedList.size()]; 
    for (int i = 0; i < closedList.size(); i++)
    {
      RadiusNode* node = closedList[i];
      movementRadius->pointsX[i] = node->gridX;
      movementRadius->pointsY[i] = node->gridY;
      movementRadius->movementCost[i] = node->costFromStart; 
    }
  }
  
  // Deallocate memory:
  for (int i = 0; i < closedList.size(); i++)
  {
    RadiusNode* node = closedList[i];
    delete node;
  }
  
  return movementRadius;
}   


// Internal method that exists to support the FindRadius method.  This method
// evaluates all the nodes in the given openList, and adds to the closedList
// all nodes that the unit can move to.  When the search is complete, the
// method will return false and the closedList will contain all viable moves.
bool HexMap::FindMovementRadius_EvaluateNode(int maximumRadius,
                                        Unit* movingUnit,
                                        RadiusNode* startNode,
                                        std::vector<RadiusNode*>* openList,
                                        std::vector<RadiusNode*>* closedList,
                                        bool obeyTerrain)
{
  // If the open list is empty, we have completed our task:
  if (openList->size() == 0)
    return false;

  // Take the first node from the open list:
  RadiusNode* node = openList->at(0);
  
  // Evaluate all neighbouring tiles... but be sure not
  // to go too far (if the path would take us off the map)
  for (int curX = (node->gridX > 0) ? node->gridX-1 : 0; 
            curX <= node->gridX + 1; 
            curX++)
  {
    // Ignore this one if we've gone off the map:
    if (curX >= gridSizeX)
      continue;
    
    for (int curY = (node->gridY > 0) ? node->gridY-1 : 0; 
              curY <= node->gridY + 1; 
              curY++)
    {
      // Ignore this one if we've gone off the map:
      if (curY >= gridSizeY)
        continue;

      // If this cell is not adjacent to the current node, skip it:
      if (! AreHexagonsAdjacent(node->gridX,node->gridY,curX,curY))
        continue;
      
      // If we are taking terrain into account, and if the given grid location
      // is impassable, skip it:
      int movementValue = 10; // TODO don't hard code this, also document it
      if (obeyTerrain && terrain != NULL && terrainIndeces != NULL)
      {
        int terrainIndex = terrainIndeces[curY*gridSizeX+curX];
        movementValue = terrain->GetMovementValue(terrainIndex);
        if (movementValue == NO_MOVEMENT)
          continue;
      }
      
      // If the node contains another unit, skip it:
      if (GetUnitAt(curX,curY))
        continue;
      
      // If the node is too far away, skip it:
      if (node->costFromStart + movementValue > maximumRadius)
        continue;
      
      // If the given hex is in an enemy ZOC, then you can enter it but
      // you can't move through it:
      Uint8 zoc = GetZOC(curX,curY);
      if (zoc & NEUTRAL_TEAM)
        zoc ^= NEUTRAL_TEAM; // Remove NEUTRAL team if present
      if (zoc & movingUnit->GetTeamID())
        zoc ^= movingUnit->GetTeamID(); // remove friendly team if present
      if (zoc) // if anything's left, it's an enemy-controlled hex
        movementValue = maximumRadius - node->costFromStart;
                    
      // If the node is too far away, skip it:
      if (node->costFromStart + movementValue > maximumRadius)
        continue;
      
      // Create a node for this position:
      RadiusNode* newNode = new RadiusNode;
      newNode->gridX = curX;
      newNode->gridY = curY;
      newNode->costFromStart = node->costFromStart + movementValue;
      newNode->parentNode = node;

      // If this node is already closed, skip it:
      if (FindRadiusNode(closedList,newNode))
      {
        delete newNode;
        continue;
      }
          
      // If this node is already in the open list, modify it:
      RadiusNode* existingNode = FindRadiusNode(openList,newNode);
      if (existingNode)
      {
        if (newNode->costFromStart < existingNode->costFromStart)
        {
          existingNode->costFromStart = newNode->costFromStart;
          existingNode->parentNode = newNode->parentNode;
        }
        delete newNode; // we'll leave the existing one in there
      }
    
      // If this node was not yet in the open list, add it now:
      else
        openList->push_back(newNode);
    }        
  }
  
  // Move current node to closed list:
  std::vector<RadiusNode*>::iterator i;
  for (i = openList->begin(); i != openList->end(); i++)
  {
    if ((*i)->gridX == node->gridX && 
        (*i)->gridY == node->gridY)
    {
      openList->erase(i);
      break;
    }
  }
  if (! FindRadiusNode(closedList,node))
  {
    closedList->push_back(node);
  }
  else
    delete node;
    
  return true; // still searching
}

    
// Internal method to find the target radius of the given unit.  Most 
// units can only target enemies that are directly adjacent to them.
// However, some units (such as artillery), can target units that
// are not adjacent.  The return value will be NULL if there are no
// enemy units within attack range.
TargetRadius* HexMap::FindTargetRadius(Unit* unit)
{
  Uint8 minAttackRange = unit->GetMinimumAttackRange();
  Uint8 maxAttackRange = unit->GetMaximumAttackRange();
  
  // Create a node for the starting position:
  RadiusNode* startNode = new RadiusNode;
  startNode->gridX = unit->GetGridX();
  startNode->gridY = unit->GetGridY();
  startNode->costFromStart = 0;
  startNode->parentNode = NULL;

  // Create a list of candidate nodes and add the start node to it:
  std::vector<RadiusNode*> openList;
  openList.push_back(startNode);
    
  // Create a list that will store all non-target nodes:
  std::vector<RadiusNode*> nonTargetList;
  
  // Create a list that will store all viable targets:
  std::vector<RadiusNode*> targetList;
  
  // Evaluate neighboring hexagons until we have
  // exhausted the attack range:  
  bool searching = true;
  while (searching)
  {
    searching = FindTargetRadius_EvaluateNode(minAttackRange,
                                              maxAttackRange,
                                              unit->GetTeamID(),
                                              &openList,
                                              &nonTargetList,
                                              &targetList);
  }
  
  // Create a radius struct and populate it:
  TargetRadius* targetRadius = NULL;
  if (targetList.size() > 0) 
  {
    targetRadius = new TargetRadius;
    targetRadius->targettingUnit = unit;
    Uint8 numTargets = targetList.size();
    targetRadius->numTargets = numTargets;
    targetRadius->pointsX = new Uint8[numTargets];
    targetRadius->pointsY = new Uint8[numTargets];
    for (int i = 0; i < targetList.size(); i++) 
    {
      RadiusNode* node = targetList[i];
      
      // Don't target yourself:
      if (node->gridX == unit->GetGridX() && node->gridY == unit->GetGridY())
        continue;
      
      targetRadius->pointsX[i] = node->gridX;
      targetRadius->pointsY[i] = node->gridY;      
    }
  }
  
  // Deallocate memory:
  for (int i = 0; i < targetList.size(); i++)
  {
    RadiusNode* node = targetList[i];
    delete node;
  }
  for (int i = 0; i < nonTargetList.size(); i++)
  {
    RadiusNode* node = nonTargetList[i];
    delete node;
  }
  
  return targetRadius;    
}

   
// Internal method that exists to support the FindTargetRadius method.
// This method will evaluate every node in the given open list, and sort
// them into the given nonTarget list and target list.  When the method 
// returns false, it means that the maximum attack range has been 
// exhausted.  At that point, the targetList will contain all viable 
// targets.
bool HexMap::FindTargetRadius_EvaluateNode(Uint8 minAttackRange,
                                       Uint8 maxAttackRange,
                                       Uint8 attackingTeam,
                                       std::vector<RadiusNode*>* openList,
                                       std::vector<RadiusNode*>* nonTargetList,
                                       std::vector<RadiusNode*>* targetList)
{
  // If the open list is empty, we have completed our task:
  if (openList->size() == 0)
    return false;

  // Take the first node out of the open list and evaluate it:
  RadiusNode* node = openList->at(0);
    
  // Evaluate all neighbouring tiles... but be sure not
  // to go too far (if the path would take us off the map)
  for (int curX = (node->gridX > 0) ? node->gridX-1 : 0; 
            curX <= node->gridX + 1; 
            curX++)
  {
    // Ignore this one if we've gone off the map:
    if (curX >= gridSizeX)
      continue;
    
    for (int curY = (node->gridY > 0) ? node->gridY-1 : 0; 
              curY <= node->gridY + 1; 
              curY++)
    {
      // Ignore this one if we've gone off the map:
      if (curY >= gridSizeY)
        continue;

      // If this cell is not adjacent to the current node, skip it:
      if (! AreHexagonsAdjacent(node->gridX,node->gridY,curX,curY))
        continue;
      
      // Create a node for this position:
      RadiusNode* newNode = new RadiusNode;
      newNode->gridX = curX;
      newNode->gridY = curY;
      newNode->costFromStart = node->costFromStart + 1;
      newNode->parentNode = node;
      
      // Add it to the open list for further consideration:
      if (! FindRadiusNode(openList,newNode) &&
          ! FindRadiusNode(nonTargetList,newNode) &&
          ! FindRadiusNode(targetList,newNode))
        openList->push_back(newNode);

      // If there is no unit at this spot, skip it:
      Unit* candidateUnit = GetUnitAt(curX,curY);
      if (! candidateUnit)
        continue;
    
      // If this unit is of the same team, skip it:
      if (candidateUnit->GetTeamID() == attackingTeam)
        continue;
        
      // If the node is too close, skip it:
      if (node->costFromStart + 1 < minAttackRange)
        continue;   
        
      // If the node is too far away, skip it:
      if (node->costFromStart + 1 > maxAttackRange)
        continue;
        
      // If we get to this point, the node is a viable target:            
        
      // If this node is already targetted, skip it:
      if (FindRadiusNode(targetList,newNode))
        continue;
        
      // If this node was not yet in the target list, add it now:
      else
        targetList->push_back(newNode);
    }        
  }
  
  // Remove this node from the open list now that we've handled it:
  std::vector<RadiusNode*>::iterator i;
  for (i = openList->begin(); i != openList->end(); i++)
  {
    if ((*i)->gridX == node->gridX && 
        (*i)->gridY == node->gridY)
    {
      openList->erase(i);
      break;
    }
  }

  // Add to non target list:  
  if (! FindRadiusNode(targetList,node))
    nonTargetList->push_back(node);
    
  return true; // still searching
}


