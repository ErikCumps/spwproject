This is part of my ongoing quest to write a Free Software clone
of the old Turbografx-16 game "Military Madness".  Included
here you will find full source code for the map engine so far,
as well as code for a simple test driver application called
"HexMapTest".  You will find a buildme.sh file for building
under Linux and a BuildMe.bat file for building on Windows.

--
Steve Corbett
www.scorbett.ca


