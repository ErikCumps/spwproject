//-----------------------------------------------------------------------------
// Copyright (C) 2005 Steve Corbett
// www.scorbett.ca
// steve@scorbett.ca
//
// You may redistribute this code provided this copyright notice is left intact
//
//------------------------------------------------------------------------------
// Created on 2005-12-15 by scorbett
//     - Initial code.
// Updated on 2005-12-16 by scorbett
//     - Added movement radius.
// Updated on 2005-12-24 by scorbett
//     - Added team support for units.
// Updated on 2005-12-26 by scorbett
//     - Added attack range.
//     - Bumped version to 2.
//-----------------------------------------------------------------------------

#include <stdio.h>
#include <string.h>
#include <SDL.h>
#include <SDL_image.h>
#include "Unit.h"
#include "Team.h"


// Creates a Unit instance using the metadata contained in the
// given file.  If the load fails for some reason, IsLoaded() will
// return false and GetLoadError() will return a descriptive
// error message.
Unit::Unit(char* unitMetaFile)
{
  // Set defaults:
  unitSurface = NULL;
  errorMessage = NULL;
  pixelSizeX = 0;
  pixelSizeY = 0;
  teamID = NEUTRAL_TEAM;
  
  // Attempt to parse unit file:
  FILE* inFile = fopen(unitMetaFile,"rb");
  
  // Ensure it is a version we can handle:
  Uint8 Version;
  fread(&Version,sizeof(Uint8),1,inFile);
  if (Version != CURRENT_VERSION)
  {
    fclose(inFile);
    errorMessage = new char[100];
    strcpy(errorMessage,"Unrecognized unit file version.");
    return;
  }
  
  // Get pixel dimensions:
  fread(&pixelSizeX,sizeof(Uint8),1,inFile);
  fread(&pixelSizeY,sizeof(Uint8),1,inFile);
  
  // Get the unit type:
  fread(&unitType,sizeof(Uint8),1,inFile);
  
  // Get the name of the unit surface file:
  Uint8 stringLength;
  fread(&stringLength,sizeof(Uint8),1,inFile);
  if (stringLength == 0)
  {
    fclose(inFile);
    errorMessage = new char[100];
    strcpy(errorMessage,"Unit file does not specify any image(s).");
    return;
  }
  char* unitImageFile = new char[stringLength+1];
  fread(unitImageFile,sizeof(char),stringLength,inFile);
  unitImageFile[stringLength] = '\0';

  // Try to load the unit image:  
  unitSurface = IMG_Load(unitImageFile);
  if (! unitSurface)
  {
    fclose(inFile);
    errorMessage = new char[100];
    strcpy(errorMessage,"Unable to load unit image(s).");
    return;
  }
  
  // Get the movement radius:
  fread(&movementRadius,sizeof(Uint8),1,inFile);
  
  // Get the attack range:
  fread(&minimumAttackRange,sizeof(Uint8),1,inFile);  
  fread(&maximumAttackRange,sizeof(Uint8),1,inFile);
  
  fclose(inFile);
  
  isMoving = false;
}


// Cleans up and destroys this instance.
Unit::~Unit()
{
  if (unitSurface)
    SDL_FreeSurface(unitSurface);
  if (errorMessage)
    delete[] errorMessage;
}


// Returns true if all is well.  If this returns false, you can call
// GetLoadError to get a descriptive error message.
bool Unit::IsLoaded()
{
  return errorMessage == NULL;
}


// Returns NULL if all is well, or an error message if the constructor
// failed to load the specified terrain metadata file.
char* Unit::GetLoadError()
{
  return errorMessage;
}


// Draws the specified unit into the specified surface at the
// specified pixel co-ordinates.  
void Unit::Draw(SDL_Surface* destSurface, int pixelX, int pixelY)
{
  // Set up a destination rect:
  SDL_Rect destRect;
  destRect.x = pixelX;
  destRect.y = pixelY;
  
  // Blit the image:
  SDL_BlitSurface(unitSurface,NULL,destSurface,&destRect);
}


// Returns the generic unit type.
Uint8 Unit::GetUnitType()
{
  return unitType;
}

                      
// Returns the pixel width of this unit.
Uint8 Unit::GetPixelSizeX()
{
  return pixelSizeX;
}


// Returns the pixel height of this unit.
Uint8 Unit::GetPixelSizeY()
{
  return pixelSizeY;
}


// Gets the movement radius of this unit.
Uint8 Unit::GetMovementRadius()
{
  return movementRadius;
}


// Sets the current grid location:
void Unit::SetLocation(Uint8 gridX, Uint8 gridY)
{
  this->gridX = gridX;
  this->gridY = gridY;
}
    

// Gets the current grid X:
Uint8 Unit::GetGridX()
{
  return gridX;
}
    
// Gets the current grid Y:
Uint8 Unit::GetGridY()
{
  return gridY;
}

// Returns whether or not this unit is currently moving:
bool Unit::IsMoving()
{
  return isMoving;
}
    
// Sets the isMoving flag to the given value (NOTE - this should really
// be handled by the map class, not the Unit class...)
void Unit::SetIsMoving(bool moving)
{
  isMoving = moving;
}


// Sets the team identifier for this unit.  (NOTE - this could go in
// the meta file for the unit in question, but it's slightly better
// to set it at runtime so that we can re-use the same meta files
// for all teams).
void Unit::SetTeamID(Uint8 team)
{
  teamID = team;
}


// Returns the team identifier for this unit:
Uint8 Unit::GetTeamID()
{
  return teamID;
}

    
// Returns the attack range of this unit:
Uint8 Unit::GetMaximumAttackRange()
{
  return maximumAttackRange;
}


// Returns the minimum attack range of this unit:
Uint8 Unit::GetMinimumAttackRange()
{
  return minimumAttackRange;
}

