#ifndef __UNIT_H
#define __UNIT_H

//-----------------------------------------------------------------------------
// Copyright (C) 2005 Steve Corbett
// www.scorbett.ca
// steve@scorbett.ca
//
// You may redistribute this code provided this copyright notice is left intact
//
//------------------------------------------------------------------------------
// Created on 2005-12-15 by scorbett
//     - Initial code.
// Updated on 2005-12-16 by scorbett
//     - Added movement radius.
// Updated on 2005-12-23 by scorbett
//     - Added isMoving as a convenience for the map engine.
// Updated on 2005-12-24 by scorbett
//     - Added team support for units.
// Updated on 2005-12-26 by scorbett
//     - Added attack range.  
//     - Bumped version to 2.
// Updated on 2005-12-27 by scorbett
//     - Renamed attackRange to maximumAttackRange
//     - Added minimumAttackRange (for artillery)
//-----------------------------------------------------------------------------

#include "Team.h"


// Generic unit types:
#define GROUND_UNIT 0
#define FLYING_UNIT 1

// For backwards compatibility (Actually not currently used, but
// in theory we could use this to load older versions of unit files).
// For now, if we detect an older version, we puke and call it a 
// load error.
#define CURRENT_VERSION 2


/**
 * A class to load and store information about the various
 * types of units that will be used in the game.
 *
 * There are two basic types of units: flying units and 
 * ground-based units.  The only significant difference
 * as far as the game code is concerned is that flying 
 * units are unaffected by terrain, both when moving and
 * when calculating a defensive bonus.
 */
class Unit
{
  private:
  
    // The image data for this unit:
    SDL_Surface* unitSurface;    

    // Generic unit type:
    Uint8 unitType;
    
    // Pixel dimensions of this unit:
    Uint8 pixelSizeX;
    Uint8 pixelSizeY;

    // Current grid location of this unit:
    Uint8 gridX;
    Uint8 gridY;
    
    // Movement radius of this unit:
    Uint8 movementRadius;

    // Indicates whether this unit is currently moving or not.
    // Note - design-wise, this probably belongs in the map class,
    // since the unit doesn't really need to know or care whether or
    // not it is moving, but for now I'm just sticking it here:
    bool isMoving;
    
    // Team identifier.  Units belonging to the same team can move
    // through each others ZOCs and cannot attack one another.
    Uint8 teamID;    

    // Max Attack range - most units have an attack range of 1, meaning they
    // can only attack enemies that are adjacent to them.  However, some
    // units (such as artillery), have a greater attack range:
    Uint8 maximumAttackRange;
    
    // Min Attack range - some units can only fire from a distance.
    // For most units, this will be 1.
    Uint8 minimumAttackRange;
        
    // TODO other stuff to go here...
        
    // Normally this will be NULL.  If a load error occurs, this will
    // be set to a descriptive error message.
    char* errorMessage;
    
  public:
  
    // Creates a Unit instance using the metadata contained in the
    // given file.  If the load fails for some reason, IsLoaded() will
    // return false and GetLoadError() will return a descriptive
    // error message.
    Unit(char* unitMetaFile);
    
    // Cleans up and destroys this instance.
    ~Unit();
    
    // Returns true if all is well.  If this returns false, you can call
    // GetLoadError to get a descriptive error message.
    bool IsLoaded();
    
    // Returns NULL if all is well, or an error message if the constructor
    // failed to load the specified unit metadata file.
    char* GetLoadError();

    // Draws the specified unit into the specified surface at the
    // specified pixel co-ordinates.  
    void Draw(SDL_Surface* destSurface, int pixelX, int pixelY);
    
    // Returns the generic unit type.
    Uint8 GetUnitType();                     
    
    // Returns the pixel width of this unit. 
    Uint8 GetPixelSizeX();
    
    // Returns the pixel height of this unit.
    Uint8 GetPixelSizeY();

    // Gets the movement radius of this unit.
    Uint8 GetMovementRadius();
        
    // Sets the current grid location:
    void SetLocation(Uint8 gridX, Uint8 gridY);
    
    // Gets the current grid X:
    Uint8 GetGridX();
    
    // Gets the current grid Y:
    Uint8 GetGridY();
    
    // Returns whether or not this unit is currently moving:
    bool IsMoving();
    
    // Sets the isMoving flag to the given value (NOTE - this should really
    // be handled by the map class, not the Unit class...)
    void SetIsMoving(bool moving);
    
    // Sets the team identifier for this unit.  (NOTE - this could go in
    // the meta file for the unit in question, but it's slightly better
    // to set it at runtime so that we can re-use the same meta files
    // for all teams).
    void SetTeamID(Uint8 team);
    
    // Returns the team identifier for this unit:
    Uint8 GetTeamID();
    
    // Returns the maximum attack range of this unit:
    Uint8 GetMaximumAttackRange();
    
    // Returns the minimum attack range of this unit:
    Uint8 GetMinimumAttackRange();
};

#endif

